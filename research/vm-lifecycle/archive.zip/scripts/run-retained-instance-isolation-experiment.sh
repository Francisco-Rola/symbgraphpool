#!/usr/bin/env bash
set -euo pipefail

root_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
probe_wasm="$root_dir/benchmarks/target/wasm32-unknown-unknown/release/acg_retained_instance_probe.wasm"

echo "==> building retained-instance probe contract"
cargo build \
  --manifest-path "$root_dir/benchmarks/Cargo.toml" \
  -p acg-retained-instance-probe \
  --release \
  --target wasm32-unknown-unknown

echo
echo "==> running retained-instance isolation experiments"
ACG_RETAINED_INSTANCE_PROBE_WASM="$probe_wasm" \
  cargo test \
    --manifest-path "$root_dir/runtime/Cargo.toml" \
    -p acg-cosmwasm-engine \
    --lib \
    retained_instance_tests:: \
    -- \
    --ignored \
    --nocapture \
    --test-threads=1
