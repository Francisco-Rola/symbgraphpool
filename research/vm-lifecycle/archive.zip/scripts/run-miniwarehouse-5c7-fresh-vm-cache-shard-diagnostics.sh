#!/usr/bin/env bash
set -euo pipefail

# Compares correct canonical fresh instantiation, correct fresh per-worker cache shards, and the
# deliberately invalid retained-VM upper bound on the six-core MiniWarehouse workload.

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

WAREHOUSES="${ACG_MW_WAREHOUSES:-16}"
BLOCK_SIZE="${ACG_MW_BLOCK_SIZE:-200}"
TOTAL_TXS="${ACG_MW_TOTAL_TXS:-1000}"
WORKERS="${ACG_MW_TOTAL_WORKERS:-6}"
PHYSICAL_CORES="${ACG_PHYSICAL_CORES:-6}"
SHARDS="${ACG_MW_FRESH_VM_CACHE_SHARDS:-$WORKERS}"
REPEATS="${ACG_MW_FRESH_VM_SHARD_REPEATS:-5}"
SOFTEN_AFTER="${ACG_MW_SYMBOLIC_HARD_SOFTEN_AFTER:-8}"
BLOCK_INTERVAL_MS="${ACG_MW_BLOCK_INTERVAL_MS:-700}"
CONSENSUS_MS="${ACG_MW_CONSENSUS_MS:-700}"

if (( WORKERS > PHYSICAL_CORES )); then
  echo "refusing to oversubscribe: workers=$WORKERS exceeds physical-core budget=$PHYSICAL_CORES" >&2
  exit 2
fi
if (( SHARDS > PHYSICAL_CORES )); then
  echo "refusing shard count above physical-core budget: shards=$SHARDS cores=$PHYSICAL_CORES" >&2
  exit 2
fi
if (( SHARDS == 0 )); then
  echo "ACG_MW_FRESH_VM_CACHE_SHARDS must be > 0 for the sharded mode" >&2
  exit 2
fi

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_DIR="${ACG_MW_FRESH_VM_SHARD_OUT_DIR:-benchmark-results/miniwarehouse-5c7-fresh-vm-cache-shards-6core/${STAMP}}"
mkdir -p "$OUT_DIR"
summary="$OUT_DIR/summary.txt"
: > "$summary"

fail_with_log() {
  local stage="$1" status="$2" log="$3"
  {
    echo
    echo "ERROR: $stage failed with exit status $status"
    echo "log: $log"
    echo "--- last 100 log lines ---"
    tail -n 100 "$log" 2>/dev/null || true
  } | tee -a "$summary" >&2
  exit "$status"
}

run_capture() {
  local stage="$1" log="$2"
  shift 2
  set +e
  "$@" 2>&1 | tee "$log"
  local status=${PIPESTATUS[0]}
  set -e
  if (( status != 0 )); then
    fail_with_log "$stage" "$status" "$log"
  fi
}

build_log="$OUT_DIR/build-miniwarehouse-wasm.log"
run_capture "MiniWarehouse Wasm build" "$build_log" \
  cargo build \
    --manifest-path benchmarks/Cargo.toml \
    -p acg-benchmark-miniwarehouse \
    --release \
    --target wasm32-unknown-unknown

metadata="$(cargo metadata --manifest-path benchmarks/Cargo.toml --format-version 1 --no-deps 2>/dev/null)"
target_dir="$(printf '%s' "$metadata" | sed -n 's/.*"target_directory":"\([^"]*\)".*/\1/p')"
if [[ -z "$target_dir" ]]; then
  target_dir="benchmarks/target"
fi
MW_WASM="$target_dir/wasm32-unknown-unknown/release/acg_benchmark_miniwarehouse.wasm"
if [[ ! -s "$MW_WASM" ]]; then
  echo "ERROR: MiniWarehouse Wasm artifact not found after successful build: $MW_WASM" | tee -a "$summary" >&2
  exit 3
fi

cat <<EOF_SUMMARY | tee -a "$summary"
=== six-core MiniWarehouse fresh-VM template-shard experiment ===
physical-core / worker budget: $PHYSICAL_CORES / $WORKERS
warehouses: $WAREHOUSES
transactions: $TOTAL_TXS
block size: $BLOCK_SIZE
repeats: $REPEATS
fresh-template shards: $SHARDS
modes: fresh sharded retained-upper-bound
fresh pool: disabled in all modes
Wasm artifact: $MW_WASM

Interpretation:
  - fresh is the correct shared CosmWasm-cache baseline;
  - sharded is correct fresh-state reconstruction from prewarmed per-worker compiled-module caches;
  - retained is the deliberately invalid dirty-instance upper bound;
  - sharded approaching retained means shared cache/instantiation contention is the main lifecycle cost;
  - sharded near fresh means fresh Store/Instance construction itself dominates and deeper snapshot/COW work is needed.

EOF_SUMMARY

for mode in fresh sharded retained-upper-bound; do
  cache_shards=0
  unsafe_reuse=0
  case "$mode" in
    fresh) ;;
    sharded) cache_shards="$SHARDS" ;;
    retained-upper-bound) unsafe_reuse=1 ;;
  esac

  for repeat in $(seq 1 "$REPEATS"); do
    log="$OUT_DIR/${mode}_repeat-${repeat}.log"
    echo "=== mode=$mode repeat=$repeat ===" | tee -a "$summary"
    set +e
    env \
      ACG_PHYSICAL_CORES="$PHYSICAL_CORES" \
      ACG_MW_WASM="$MW_WASM" \
      ACG_MW_WAREHOUSES="$WAREHOUSES" \
      ACG_MW_BLOCK_SIZE="$BLOCK_SIZE" \
      ACG_MW_TOTAL_TXS="$TOTAL_TXS" \
      ACG_MW_TOTAL_WORKERS="$WORKERS" \
      ACG_MW_BLOCK_INTERVAL_MS="$BLOCK_INTERVAL_MS" \
      ACG_MW_CONSENSUS_MS="$CONSENSUS_MS" \
      ACG_MW_REQUIRE_PREEXEC_WITHIN_CONSENSUS=0 \
      ACG_MW_SYMBOLIC_HARD_SOFTEN_AFTER="$SOFTEN_AFTER" \
      ACG_MW_WASM_POOL_PREPARERS=0 \
      ACG_MW_WASM_POOL_TARGET_PER_CODE=0 \
      ACG_MW_WASM_POOL_INITIAL_PER_CODE=0 \
      ACG_MW_WASM_POOL_ADAPTIVE=0 \
      ACG_MW_FRESH_VM_CACHE_SHARDS="$cache_shards" \
      ACG_MW_UNSAFE_REUSE_WASM_INSTANCES="$unsafe_reuse" \
      RUST_BACKTRACE=1 \
      cargo test \
        --release \
        --manifest-path runtime/Cargo.toml \
        -p acg-miniwarehouse-workload \
        --test parallelism_metrics \
        -- \
        --nocapture --test-threads=1 2>&1 | tee "$log"
    status=${PIPESTATUS[0]}
    set -e
    if (( status != 0 )); then
      fail_with_log "MiniWarehouse $mode probe" "$status" "$log"
    fi
    if ! grep -Fq 'MiniWarehouse Brick-5C.7 block-local MVCC measurement' "$log"; then
      fail_with_log "MiniWarehouse $mode probe produced no diagnostic marker" 4 "$log"
    fi
    if [[ "$mode" == "sharded" ]] && ! grep -Fq 'Fresh-cache-shard final world matches fresh serial: YES' "$log"; then
      fail_with_log "MiniWarehouse sharded final-state equivalence marker missing" 4 "$log"
    fi

    grep -E \
      'Fresh-cache-shard final world matches fresh serial:|UNSAFE retained VM final world matches fresh serial:|serial-equivalent work:|actual parallel preexecute:|dependency-DAG lower bound:|observed-service DAG bound:|REALIZED preexec speedup:|worker phase wall:|execution phase wall excl fill:|observed service / serial:|execution / observed DAG bound:|wall gap above observed bound:|effective contract concurrency:|max in-flight transactions:|fresh VM cache shards:|UNSAFE retained Wasm VM reuse:|aggregate request execution:|aggregate Wasm instance acquire:|fresh-cache-shard acquires:|aggregate retained VM rebind:|retained VM reuse / returns:|aggregate Wasm entrypoint:|aggregate Wasm recycle:|aggregate host storage callbacks:|aggregate MVCC storage point:|aggregate MVCC publish:|Wasm instance acquires:|Wasm entrypoint calls:|reuse rate:|replay rate:' \
      "$log" | tee -a "$summary" || true
    echo | tee -a "$summary"
  done
done

echo "Logs: $OUT_DIR"
echo "Summary: $summary"
