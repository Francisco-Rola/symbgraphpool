#!/usr/bin/env bash
set -euo pipefail

# Six-core storage-free Wasm compute scaling experiment.
#
# Uses a dedicated compute-only Wasm contract. All Cargo stderr is captured so a failed probe leaves
# an actionable summary instead of a header-only file.

TXS="${ACG_COMPUTE_TXS:-200}"
WORKERS="${ACG_COMPUTE_WORKERS:-6}"
PHYSICAL_CORES="${ACG_PHYSICAL_CORES:-6}"
if (( WORKERS > PHYSICAL_CORES )); then
  echo "refusing to oversubscribe: workers=$WORKERS exceeds physical-core budget=$PHYSICAL_CORES" >&2
  exit 2
fi
REPEATS="${ACG_COMPUTE_REPEATS:-3}"
ITERATION_LEVELS="${ACG_COMPUTE_ITERATION_LEVELS:-0 4096 32768 262144}"
MEMORY_WORDS="${ACG_COMPUTE_MEMORY_WORDS:-0}"
INITIAL="${ACG_COMPUTE_POOL_INITIAL:-6}"
LOW="${ACG_COMPUTE_POOL_LOW_WATERMARK:-12}"
TARGET="${ACG_COMPUTE_POOL_TARGET:-48}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_DIR="${ACG_COMPUTE_OUT_DIR:-benchmark-results/wasm-compute-scaling-6core/${STAMP}}"
mkdir -p "$OUT_DIR"

summary="$OUT_DIR/summary.txt"
: > "$summary"
cat <<EOF_SUMMARY | tee -a "$summary"
=== six-core storage-free Wasm compute scaling experiment ===
transactions: $TXS
physical-core / worker budget: $PHYSICAL_CORES / $WORKERS
repeats: $REPEATS
iteration levels: $ITERATION_LEVELS
memory words: $MEMORY_WORDS
pool modes: off, fixed(1:$TARGET:$INITIAL), adaptive(max-prep=1 low=$LOW high=$TARGET initial=$INITIAL)
dependency lanes: $TXS (fully independent)

Interpretation:
  - pool-off is the clean six-core scaling reference;
  - fixed-pool quantifies the cost of permanently sacrificing one of six cores;
  - adaptive-pool tests whether refill can preserve the reserve and still return all six workers to execution;
  - execution/observed-bound near 1.0 means scheduler realization is good and remaining loss is per-tx service inflation.

EOF_SUMMARY

fail_with_log() {
  local stage="$1" status="$2" log="$3"
  {
    echo
    echo "ERROR: $stage failed with exit status $status"
    echo "log: $log"
    echo "--- last 80 log lines ---"
    tail -n 80 "$log" 2>/dev/null || true
  } | tee -a "$summary" >&2
  exit "$status"
}

run_capture() {
  local stage="$1" log="$2"
  shift 2
  set +e
  "$@" 2>&1 | tee "$log"
  local status=${PIPESTATUS[0]}
  set -e
  if (( status != 0 )); then
    fail_with_log "$stage" "$status" "$log"
  fi
}

build_log="$OUT_DIR/build-compute-probe.log"
run_capture "compute-probe Wasm build" "$build_log" \
  cargo build \
    --manifest-path benchmarks/Cargo.toml \
    -p acg-wasm-compute-probe \
    --release \
    --target wasm32-unknown-unknown

metadata="$(cargo metadata --manifest-path benchmarks/Cargo.toml --format-version 1 --no-deps 2>/dev/null)"
target_dir="$(printf '%s' "$metadata" | sed -n 's/.*"target_directory":"\([^"]*\)".*/\1/p')"
if [[ -z "$target_dir" ]]; then
  target_dir="benchmarks/target"
fi
COMPUTE_WASM="$target_dir/wasm32-unknown-unknown/release/acg_wasm_compute_probe.wasm"
if [[ ! -s "$COMPUTE_WASM" ]]; then
  echo "ERROR: compute-probe artifact not found after successful build: $COMPUTE_WASM" | tee -a "$summary" >&2
  exit 3
fi
echo "compute probe artifact: $COMPUTE_WASM" | tee -a "$summary"
echo | tee -a "$summary"

preflight_log="$OUT_DIR/preflight-wasm-compute-scaling.log"
run_capture "wasm_compute_scaling integration-test compile" "$preflight_log" \
  cargo test \
    --release \
    --manifest-path runtime/Cargo.toml \
    -p acg-cosmwasm-engine \
    --test wasm_compute_scaling \
    --no-run

run_probe() {
  local log="$1"
  shift
  set +e
  env "$@" \
    ACG_PHYSICAL_CORES="$PHYSICAL_CORES" \
    ACG_COMPUTE_WASM="$COMPUTE_WASM" \
    ACG_COMPUTE_PROBE_KIND=burn \
    RUST_BACKTRACE=1 \
    cargo test \
      --release \
      --manifest-path runtime/Cargo.toml \
      -p acg-cosmwasm-engine \
      --test wasm_compute_scaling \
      -- \
      --ignored --nocapture --test-threads=1 compute_scaling_probe 2>&1 | tee "$log"
  local status=${PIPESTATUS[0]}
  set -e
  if (( status != 0 )); then
    fail_with_log "compute scaling probe" "$status" "$log"
  fi
  if ! grep -Fq '=== Wasm compute scaling probe ===' "$log"; then
    fail_with_log "compute scaling probe produced no diagnostic marker" 4 "$log"
  fi
}

for iterations in $ITERATION_LEVELS; do
  for mode in off fixed-pool adaptive-pool; do
    case "$mode" in
      off)
        preparers=0; target=0; initial=0; adaptive=0; low=0 ;;
      fixed-pool)
        preparers=1; target="$TARGET"; initial="$INITIAL"; adaptive=0; low=0 ;;
      adaptive-pool)
        preparers=1; target="$TARGET"; initial="$INITIAL"; adaptive=1; low="$LOW" ;;
    esac

    for repeat in $(seq 1 "$REPEATS"); do
      log="$OUT_DIR/iterations-${iterations}_${mode}_repeat-${repeat}.log"
      echo "=== iterations=$iterations mode=$mode repeat=$repeat ===" | tee -a "$summary"
      run_probe "$log" \
        ACG_COMPUTE_TXS="$TXS" \
        ACG_COMPUTE_WORKERS="$WORKERS" \
        ACG_COMPUTE_ITERATIONS="$iterations" \
        ACG_COMPUTE_MEMORY_WORDS="$MEMORY_WORDS" \
        ACG_COMPUTE_STORAGE_READS=0 \
        ACG_COMPUTE_STORAGE_WRITES=0 \
        ACG_COMPUTE_LANES="$TXS" \
        ACG_COMPUTE_POOL_PREPARERS="$preparers" \
        ACG_COMPUTE_POOL_TARGET="$target" \
        ACG_COMPUTE_POOL_INITIAL="$initial" \
        ACG_COMPUTE_POOL_ADAPTIVE="$adaptive" \
        ACG_COMPUTE_POOL_LOW_WATERMARK="$low"

      grep -E \
        'probe kind:|transactions / lanes:|workers total / execution:|pool prep/target/initial:|pool adaptive / low watermark:|iterations / memory words:|serial wall:|serial tx work sum:|serial-cost DAG bound:|parallel preexecute wall:|parallel execution excl fill:|observed-service DAG bound:|serial / parallel speedup:|theoretical speedup:|execution / observed bound:|scheduler mutex wait:|dependency condvar sleep:|dependency sleep events:|avg / max ready depth:|worker tx min / max:|aggregate contract\+receipt:|aggregate Wasm pool wait:|aggregate Wasm entrypoint:|aggregate Wasm recycle:|pool immediate / waited:|pool max available / waiters:|pool unused instances:' \
        "$log" | tee -a "$summary" || true
      echo | tee -a "$summary"
    done
  done
done

echo "Logs: $OUT_DIR"
echo "Summary: $summary"
