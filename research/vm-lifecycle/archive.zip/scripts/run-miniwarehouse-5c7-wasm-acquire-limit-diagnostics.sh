#!/usr/bin/env bash
set -euo pipefail

WAREHOUSES="${ACG_MW_WAREHOUSES:-16}"
BLOCK_SIZE="${ACG_MW_BLOCK_SIZE:-200}"
TOTAL_TXS="${ACG_MW_TOTAL_TXS:-1000}"
WORKERS="${ACG_MW_TOTAL_WORKERS:-6}"
PHYSICAL_CORES="${ACG_PHYSICAL_CORES:-6}"
if (( WORKERS > PHYSICAL_CORES )); then
  echo "refusing to oversubscribe: workers=$WORKERS exceeds physical-core budget=$PHYSICAL_CORES" >&2
  exit 2
fi
REPEATS="${ACG_MW_DIAG_REPEATS:-3}"
ACQUIRE_LIMITS="${ACG_MW_DIAG_ACQUIRE_LIMITS:-unlimited 1 2 4 6}"
SOFTEN_AFTER="${ACG_MW_SYMBOLIC_HARD_SOFTEN_AFTER:-8}"
BLOCK_INTERVAL_MS="${ACG_MW_BLOCK_INTERVAL_MS:-700}"
CONSENSUS_MS="${ACG_MW_CONSENSUS_MS:-700}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_DIR="${ACG_MW_DIAG_OUT_DIR:-benchmark-results/miniwarehouse-5c7-wasm-acquire-limit/${STAMP}}"
mkdir -p "$OUT_DIR"

summary="$OUT_DIR/summary.txt"
: > "$summary"

for acquire_limit in $ACQUIRE_LIMITS; do
  for repeat in $(seq 1 "$REPEATS"); do
    log="$OUT_DIR/acquire-${acquire_limit}_repeat-${repeat}.log"
    echo "=== workers=$WORKERS acquire_limit=$acquire_limit repeat=$repeat ===" | tee -a "$summary"
    acquire_env=()
    if [[ "$acquire_limit" != "unlimited" ]]; then
      acquire_env=(ACG_MW_WASM_ACQUIRE_LIMIT="$acquire_limit")
    fi

    env \
      ACG_MW_WAREHOUSES="$WAREHOUSES" \
      ACG_MW_TOTAL_TXS="$TOTAL_TXS" \
      ACG_MW_BLOCK_SIZE="$BLOCK_SIZE" \
      ACG_MW_TOTAL_WORKERS="$WORKERS" \
      ACG_MW_BLOCK_INTERVAL_MS="$BLOCK_INTERVAL_MS" \
      ACG_MW_CONSENSUS_MS="$CONSENSUS_MS" \
      ACG_MW_SYMBOLIC_HARD_SOFTEN_AFTER="$SOFTEN_AFTER" \
      "${acquire_env[@]}" \
    cargo test \
      --release \
      --manifest-path runtime/Cargo.toml \
      -p acg-miniwarehouse-workload \
      --test parallelism_metrics \
      -- \
      --nocapture --test-threads=1 | tee "$log"

    grep -E \
      'Wasm acquire concurrency cap:|serial-equivalent work:|actual parallel preexecute:|REALIZED preexec speedup:|dependency-DAG lower bound:|worker phase wall:|aggregate ready/lock wait:|aggregate contract\+receipt:|speculative contract cost / serial:|effective contract concurrency:|worker busy capacity:|worker ready/wait capacity:|max in-flight transactions:|aggregate request execution:|aggregate receipt finalization:|aggregate backend construction:|aggregate Wasm acquire throttle wait:|aggregate Wasm instance acquire:|aggregate Wasm entrypoint:|aggregate Wasm recycle:|aggregate Wasm runtime total:|aggregate host storage callbacks:|aggregate tx-lock wait in host:|aggregate MVCC lock wait:|Wasm instance acquires:|Wasm entrypoint calls:|Wasm cache pinned/mem/fs/miss:|host storage ops / tx:|reuse rate:|replay rate:|POST-CONSENSUS SPEEDUP:' \
      "$log" | tee -a "$summary"
    echo | tee -a "$summary"
  done
done

echo "Logs: $OUT_DIR"
echo "Summary: $summary"
