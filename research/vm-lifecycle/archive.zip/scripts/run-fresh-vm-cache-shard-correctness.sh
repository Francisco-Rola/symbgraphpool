#!/usr/bin/env bash
set -euo pipefail

# Correctness gate for the fresh-VM cache-shard prototype. Unlike unsafe retained reuse, the shard
# design must preserve fresh linear memory/gas/backend state on every call while allowing six caches
# to instantiate concurrently.

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

PHYSICAL_CORES="${ACG_PHYSICAL_CORES:-6}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_DIR="${ACG_FRESH_VM_SHARD_TEST_OUT_DIR:-benchmark-results/fresh-vm-cache-shard-correctness/${STAMP}}"
mkdir -p "$OUT_DIR"
summary="$OUT_DIR/summary.txt"
: > "$summary"

fail_with_log() {
  local stage="$1" status="$2" log="$3"
  {
    echo
    echo "ERROR: $stage failed with exit status $status"
    echo "log: $log"
    echo "--- last 120 log lines ---"
    tail -n 120 "$log" 2>/dev/null || true
  } | tee -a "$summary" >&2
  exit "$status"
}

run_capture() {
  local stage="$1" log="$2"
  shift 2
  set +e
  "$@" 2>&1 | tee "$log"
  local status=${PIPESTATUS[0]}
  set -e
  if (( status != 0 )); then
    fail_with_log "$stage" "$status" "$log"
  fi
}

build_log="$OUT_DIR/build-retained-probe.log"
run_capture "retained-instance probe Wasm build" "$build_log" \
  cargo build \
    --manifest-path benchmarks/Cargo.toml \
    -p acg-retained-instance-probe \
    --release \
    --target wasm32-unknown-unknown

metadata="$(cargo metadata --manifest-path benchmarks/Cargo.toml --format-version 1 --no-deps 2>/dev/null)"
target_dir="$(printf '%s' "$metadata" | sed -n 's/.*"target_directory":"\([^"]*\)".*/\1/p')"
if [[ -z "$target_dir" ]]; then
  target_dir="benchmarks/target"
fi
PROBE_WASM="$target_dir/wasm32-unknown-unknown/release/acg_retained_instance_probe.wasm"
if [[ ! -s "$PROBE_WASM" ]]; then
  echo "ERROR: retained-instance probe Wasm artifact missing: $PROBE_WASM" | tee -a "$summary" >&2
  exit 3
fi

cat <<EOF_SUMMARY | tee -a "$summary"
=== fresh-VM cache-shard correctness gate ===
physical-core budget: $PHYSICAL_CORES
prototype shards under stress: 6
probe Wasm: $PROBE_WASM

Required properties:
  1. sequential calls through one shard see pristine VM-local memory/sentinel state;
  2. gas and initial memory size reset between calls;
  3. storage/querier backends belong to the current transaction;
  4. six independent cache shards can instantiate concurrently without state leakage/panic;
  5. the existing unsafe-retained test remains a negative control and still demonstrates leakage.

EOF_SUMMARY

test_log="$OUT_DIR/retained-instance-tests.log"
set +e
env \
  ACG_PHYSICAL_CORES="$PHYSICAL_CORES" \
  ACG_RETAINED_INSTANCE_PROBE_WASM="$PROBE_WASM" \
  RUST_BACKTRACE=1 \
  cargo test \
    --release \
    --manifest-path runtime/Cargo.toml \
    -p acg-cosmwasm-engine \
    --lib \
    retained_instance_tests:: \
    -- \
    --ignored --nocapture --test-threads=1 2>&1 | tee "$test_log"
status=${PIPESTATUS[0]}
set -e
if (( status != 0 )); then
  fail_with_log "fresh-VM cache-shard correctness tests" "$status" "$test_log"
fi

if ! grep -Fq 'fresh-cache-shard semantic reset:' "$test_log"; then
  fail_with_log "semantic-reset marker missing" 4 "$test_log"
fi
if ! grep -Fq 'fresh-cache-shard concurrent isolation:' "$test_log"; then
  fail_with_log "concurrent-isolation marker missing" 4 "$test_log"
fi
if ! grep -Fq 'raw retained Instance reuse leaks VM-local memory' "$test_log"; then
  fail_with_log "unsafe-retained negative-control marker missing" 4 "$test_log"
fi

{
  echo "=== correctness results ==="
  grep -E \
    'fresh-instance baseline:|fresh-cache-shard semantic reset:|same shard call A/B|initial gas A/B|fresh-cache-shard concurrent isolation:|retained-instance isolation experiment:|verdict: backend rebinding works|fresh-pool isolation experiment:|test result:' \
    "$test_log" || true
  echo
  echo "PASS: fresh-cache-shard correctness gate completed."
} | tee -a "$summary"

echo "Logs: $OUT_DIR"
echo "Summary: $summary"
