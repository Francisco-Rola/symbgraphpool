#!/usr/bin/env bash
set -euo pipefail

# Controlled six-core READY-DAG shape experiment.
#
# Uses the dedicated compute-only Wasm probe with the pool disabled. Captures stderr/backtraces so
# failures are preserved in the summary rather than leaving a header-only result.

TXS="${ACG_DAG_PROBE_TXS:-200}"
WORKERS="${ACG_DAG_PROBE_WORKERS:-6}"
PHYSICAL_CORES="${ACG_PHYSICAL_CORES:-6}"
if (( WORKERS > PHYSICAL_CORES )); then
  echo "refusing to oversubscribe: workers=$WORKERS exceeds physical-core budget=$PHYSICAL_CORES" >&2
  exit 2
fi
REPEATS="${ACG_DAG_PROBE_REPEATS:-3}"
ITERATIONS="${ACG_DAG_PROBE_ITERATIONS:-262144}"
MEMORY_WORDS="${ACG_DAG_PROBE_MEMORY_WORDS:-0}"
LANES_LIST="${ACG_DAG_PROBE_LANES:-$TXS 6 4 2 1}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_DIR="${ACG_DAG_PROBE_OUT_DIR:-benchmark-results/ready-dag-shape-6core/${STAMP}}"
mkdir -p "$OUT_DIR"

summary="$OUT_DIR/summary.txt"
: > "$summary"
cat <<EOF_SUMMARY | tee -a "$summary"
=== controlled six-core READY-DAG shape experiment ===
transactions: $TXS
physical-core / worker budget: $PHYSICAL_CORES / $WORKERS
repeats: $REPEATS
iterations: $ITERATIONS
memory words: $MEMORY_WORDS
lanes: $LANES_LIST
pool: off (scheduler isolation)

Interpretation:
  - lanes >= 6 should approach the six-worker bound for compute-heavy transactions;
  - lanes=4/2/1 should follow the corresponding dependency-chain critical path;
  - execution/observed-bound isolates scheduler realization from concurrent per-tx service inflation;
  - this experiment must stay pool-off so VM refill behavior cannot masquerade as DAG inefficiency.

EOF_SUMMARY

fail_with_log() {
  local stage="$1" status="$2" log="$3"
  {
    echo
    echo "ERROR: $stage failed with exit status $status"
    echo "log: $log"
    echo "--- last 80 log lines ---"
    tail -n 80 "$log" 2>/dev/null || true
  } | tee -a "$summary" >&2
  exit "$status"
}

run_capture() {
  local stage="$1" log="$2"
  shift 2
  set +e
  "$@" 2>&1 | tee "$log"
  local status=${PIPESTATUS[0]}
  set -e
  if (( status != 0 )); then
    fail_with_log "$stage" "$status" "$log"
  fi
}

build_log="$OUT_DIR/build-compute-probe.log"
run_capture "compute-probe Wasm build" "$build_log" \
  cargo build \
    --manifest-path benchmarks/Cargo.toml \
    -p acg-wasm-compute-probe \
    --release \
    --target wasm32-unknown-unknown

metadata="$(cargo metadata --manifest-path benchmarks/Cargo.toml --format-version 1 --no-deps 2>/dev/null)"
target_dir="$(printf '%s' "$metadata" | sed -n 's/.*"target_directory":"\([^"]*\)".*/\1/p')"
if [[ -z "$target_dir" ]]; then
  target_dir="benchmarks/target"
fi
COMPUTE_WASM="$target_dir/wasm32-unknown-unknown/release/acg_wasm_compute_probe.wasm"
if [[ ! -s "$COMPUTE_WASM" ]]; then
  echo "ERROR: compute-probe artifact not found after successful build: $COMPUTE_WASM" | tee -a "$summary" >&2
  exit 3
fi
echo "compute probe artifact: $COMPUTE_WASM" | tee -a "$summary"
echo | tee -a "$summary"

preflight_log="$OUT_DIR/preflight-wasm-compute-scaling.log"
run_capture "wasm_compute_scaling integration-test compile" "$preflight_log" \
  cargo test \
    --release \
    --manifest-path runtime/Cargo.toml \
    -p acg-cosmwasm-engine \
    --test wasm_compute_scaling \
    --no-run

run_probe() {
  local log="$1"
  shift
  set +e
  env "$@" \
    ACG_PHYSICAL_CORES="$PHYSICAL_CORES" \
    ACG_COMPUTE_WASM="$COMPUTE_WASM" \
    ACG_COMPUTE_PROBE_KIND=burn \
    RUST_BACKTRACE=1 \
    cargo test \
      --release \
      --manifest-path runtime/Cargo.toml \
      -p acg-cosmwasm-engine \
      --test wasm_compute_scaling \
      -- \
      --ignored --nocapture --test-threads=1 compute_scaling_probe 2>&1 | tee "$log"
  local status=${PIPESTATUS[0]}
  set -e
  if (( status != 0 )); then
    fail_with_log "READY-DAG probe" "$status" "$log"
  fi
  if ! grep -Fq '=== Wasm compute scaling probe ===' "$log"; then
    fail_with_log "READY-DAG probe produced no diagnostic marker" 4 "$log"
  fi
}

for lanes in $LANES_LIST; do
  for repeat in $(seq 1 "$REPEATS"); do
    log="$OUT_DIR/lanes-${lanes}_repeat-${repeat}.log"
    echo "=== lanes=$lanes repeat=$repeat ===" | tee -a "$summary"
    run_probe "$log" \
      ACG_COMPUTE_TXS="$TXS" \
      ACG_COMPUTE_WORKERS="$WORKERS" \
      ACG_COMPUTE_ITERATIONS="$ITERATIONS" \
      ACG_COMPUTE_MEMORY_WORDS="$MEMORY_WORDS" \
      ACG_COMPUTE_STORAGE_READS=0 \
      ACG_COMPUTE_STORAGE_WRITES=0 \
      ACG_COMPUTE_LANES="$lanes" \
      ACG_COMPUTE_POOL_PREPARERS=0 \
      ACG_COMPUTE_POOL_TARGET=0 \
      ACG_COMPUTE_POOL_INITIAL=0 \
      ACG_COMPUTE_POOL_ADAPTIVE=0 \
      ACG_COMPUTE_POOL_LOW_WATERMARK=0

    grep -E \
      'probe kind:|transactions / lanes:|workers total / execution:|iterations / memory words:|serial wall:|serial-cost DAG bound:|parallel preexecute wall:|parallel execution excl fill:|observed-service DAG bound:|serial / parallel speedup:|theoretical speedup:|execution / observed bound:|scheduler mutex wait:|dependency condvar sleep:|dependency sleep events:|avg / max ready depth:|worker tx min / max:|aggregate contract\+receipt:|aggregate Wasm entrypoint:' \
      "$log" | tee -a "$summary" || true
    echo | tee -a "$summary"
  done
done

echo "Logs: $OUT_DIR"
echo "Summary: $summary"
