#!/usr/bin/env bash
set -euo pipefail

WAREHOUSES="${ACG_MW_WAREHOUSES:-16}"
BLOCK_SIZE="${ACG_MW_BLOCK_SIZE:-200}"
TOTAL_TXS="${ACG_MW_TOTAL_TXS:-1000}"
WORKERS="${ACG_MW_TOTAL_WORKERS:-6}"
PHYSICAL_CORES="${ACG_PHYSICAL_CORES:-6}"
if (( WORKERS > PHYSICAL_CORES )); then
  echo "refusing to oversubscribe: workers=$WORKERS exceeds physical-core budget=$PHYSICAL_CORES" >&2
  exit 2
fi
REPEATS="${ACG_MW_DIAG_REPEATS:-3}"
POOL_CONFIGS="${ACG_MW_DIAG_POOL_CONFIGS:-off 1:2:1 1:4:1 2:4:1 2:8:2 3:8:2}"
SOFTEN_AFTER="${ACG_MW_SYMBOLIC_HARD_SOFTEN_AFTER:-8}"
BLOCK_INTERVAL_MS="${ACG_MW_BLOCK_INTERVAL_MS:-700}"
CONSENSUS_MS="${ACG_MW_CONSENSUS_MS:-700}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_DIR="${ACG_MW_DIAG_OUT_DIR:-benchmark-results/miniwarehouse-5c7-fresh-instance-pool/${STAMP}}"
mkdir -p "$OUT_DIR"

summary="$OUT_DIR/summary.txt"
: > "$summary"

for pool_config in $POOL_CONFIGS; do
  if [[ "$pool_config" == "off" ]]; then
    preparers=0
    target=0
    initial=0
  else
    IFS=: read -r preparers target initial <<< "$pool_config"
  fi

  for repeat in $(seq 1 "$REPEATS"); do
    log="$OUT_DIR/pool-${pool_config//:/-}_repeat-${repeat}.log"
    echo "=== workers=$WORKERS pool=$pool_config repeat=$repeat ===" | tee -a "$summary"

    env -u ACG_MW_WASM_ACQUIRE_LIMIT \
      ACG_MW_WAREHOUSES="$WAREHOUSES" \
      ACG_MW_TOTAL_TXS="$TOTAL_TXS" \
      ACG_MW_BLOCK_SIZE="$BLOCK_SIZE" \
      ACG_MW_TOTAL_WORKERS="$WORKERS" \
      ACG_MW_BLOCK_INTERVAL_MS="$BLOCK_INTERVAL_MS" \
      ACG_MW_CONSENSUS_MS="$CONSENSUS_MS" \
      ACG_MW_SYMBOLIC_HARD_SOFTEN_AFTER="$SOFTEN_AFTER" \
      ACG_MW_WASM_POOL_PREPARERS="$preparers" \
      ACG_MW_WASM_POOL_TARGET_PER_CODE="$target" \
      ACG_MW_WASM_POOL_INITIAL_PER_CODE="$initial" \
    cargo test \
      --release \
      --manifest-path runtime/Cargo.toml \
      -p acg-miniwarehouse-workload \
      --test parallelism_metrics \
      -- \
      --nocapture --test-threads=1 | tee "$log"

    grep -E \
      'fresh Wasm pool prep/target/initial:|serial-equivalent work:|actual parallel preexecute:|REALIZED preexec speedup:|dependency-DAG lower bound:|worker phase wall:|execution phase wall excl fill:|aggregate ready/lock wait:|aggregate contract\+receipt:|speculative contract cost / serial:|effective contract concurrency:|worker busy capacity:|worker ready/wait capacity:|max in-flight transactions:|Fresh Wasm instance pool|enabled:|preparer / execution threads:|target per code:|predicted code checksums:|initial fill wall:|aggregate prepare time:|aggregate pool wait:|aggregate backend rebind:|preparer busy capacity:|prepared instances:|pool requests:|immediate / waited requests:|consumed / unused instances:|aggregate Wasm instance acquire:|aggregate Wasm entrypoint:|aggregate Wasm recycle:|Wasm instance acquires:|Wasm entrypoint calls:|Wasm cache pinned/mem/fs/miss:|reuse rate:|replay rate:|POST-CONSENSUS SPEEDUP:' \
      "$log" | tee -a "$summary"
    echo | tee -a "$summary"
  done
done

echo "Logs: $OUT_DIR"
echo "Summary: $summary"
