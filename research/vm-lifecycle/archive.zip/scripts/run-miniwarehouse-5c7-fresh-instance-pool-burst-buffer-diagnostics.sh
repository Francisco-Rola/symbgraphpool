#!/usr/bin/env bash
set -euo pipefail

# Focused steady-state reserve experiment for the fresh Wasm instance pool.
#
# The previous sweep established that one preparer has ample average capacity, but workers consume
# instances in bursts. This follow-up deliberately keeps the initial fill small and increases only
# the steady-state reserve, up to one full benchmark block worth of pristine instances per code.
# That lets the preparer spend its otherwise-idle time building a deeper buffer without moving the
# preparation cost back into the pre-execution cold-start path.
#
# Tuple format in the summary:
#   preparer_threads:target_fresh_instances_per_code:initial_fill_per_code

WAREHOUSES="${ACG_MW_WAREHOUSES:-16}"
BLOCK_SIZE="${ACG_MW_BLOCK_SIZE:-200}"
TOTAL_TXS="${ACG_MW_TOTAL_TXS:-1000}"
WORKERS="${ACG_MW_TOTAL_WORKERS:-6}"
PHYSICAL_CORES="${ACG_PHYSICAL_CORES:-6}"
if (( WORKERS > PHYSICAL_CORES )); then
  echo "refusing to oversubscribe: workers=$WORKERS exceeds physical-core budget=$PHYSICAL_CORES" >&2
  exit 2
fi
REPEATS="${ACG_MW_BURST_REPEATS:-5}"
INITIAL="${ACG_MW_BURST_INITIAL_PER_CODE:-6}"
TARGETS="${ACG_MW_BURST_TARGETS:-16 24 32 48 64 96 128 $BLOCK_SIZE}"
SOFTEN_AFTER="${ACG_MW_SYMBOLIC_HARD_SOFTEN_AFTER:-8}"
BLOCK_INTERVAL_MS="${ACG_MW_BLOCK_INTERVAL_MS:-700}"
CONSENSUS_MS="${ACG_MW_CONSENSUS_MS:-700}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_DIR="${ACG_MW_BURST_OUT_DIR:-benchmark-results/miniwarehouse-5c7-fresh-instance-pool-steady-reserve/${STAMP}}"
mkdir -p "$OUT_DIR"

if (( INITIAL > BLOCK_SIZE )); then
  echo "initial fill ($INITIAL) cannot exceed block size ($BLOCK_SIZE)" >&2
  exit 2
fi

# Keep off as the control, then build a deduplicated ascending-ish list of one-preparer targets.
# Values above BLOCK_SIZE are skipped because the experiment intentionally caps the reserve at one
# block worth of VMs per checksum.
POOL_CONFIGS=(off)
declare -A seen_targets=()
for target in $TARGETS; do
  if (( target < INITIAL || target > BLOCK_SIZE )); then
    continue
  fi
  if [[ -n "${seen_targets[$target]:-}" ]]; then
    continue
  fi
  seen_targets[$target]=1
  POOL_CONFIGS+=("1:${target}:${INITIAL}")
done

# Always include the exact block-size endpoint unless it was already present.
if [[ -z "${seen_targets[$BLOCK_SIZE]:-}" ]]; then
  POOL_CONFIGS+=("1:${BLOCK_SIZE}:${INITIAL}")
fi

summary="$OUT_DIR/summary.txt"
: > "$summary"

cat <<EOF_SUMMARY | tee -a "$summary"
=== fresh Wasm pool steady-state reserve experiment ===
workers: $WORKERS
warehouses: $WAREHOUSES
transactions: $TOTAL_TXS
block size: $BLOCK_SIZE
repeats: $REPEATS
initial fill per code: $INITIAL
pool configs: ${POOL_CONFIGS[*]}
hypothesis: one preparer has spare average capacity; deeper steady reserves should absorb READY-DAG bursts without increasing cold-start fill

EOF_SUMMARY

for pool_config in "${POOL_CONFIGS[@]}"; do
  if [[ "$pool_config" == "off" ]]; then
    preparers=0
    target=0
    initial=0
  else
    IFS=: read -r preparers target initial <<< "$pool_config"

    if (( preparers != 1 )); then
      echo "invalid steady-reserve config '$pool_config': this experiment keeps exactly one preparer" >&2
      exit 2
    fi
    if (( target == 0 || initial > target || target > BLOCK_SIZE )); then
      echo "invalid pool config '$pool_config': require initial <= target <= block size" >&2
      exit 2
    fi
  fi

  for repeat in $(seq 1 "$REPEATS"); do
    log="$OUT_DIR/pool-${pool_config//:/-}_repeat-${repeat}.log"
    echo "=== workers=$WORKERS pool=$pool_config repeat=$repeat ===" | tee -a "$summary"

    # Keep the previous Wasm acquisition semaphore experiment out of this run.
    env -u ACG_MW_WASM_ACQUIRE_LIMIT \
      ACG_MW_WAREHOUSES="$WAREHOUSES" \
      ACG_MW_TOTAL_TXS="$TOTAL_TXS" \
      ACG_MW_BLOCK_SIZE="$BLOCK_SIZE" \
      ACG_MW_TOTAL_WORKERS="$WORKERS" \
      ACG_MW_BLOCK_INTERVAL_MS="$BLOCK_INTERVAL_MS" \
      ACG_MW_CONSENSUS_MS="$CONSENSUS_MS" \
      ACG_MW_SYMBOLIC_HARD_SOFTEN_AFTER="$SOFTEN_AFTER" \
      ACG_MW_WASM_POOL_PREPARERS="$preparers" \
      ACG_MW_WASM_POOL_TARGET_PER_CODE="$target" \
      ACG_MW_WASM_POOL_INITIAL_PER_CODE="$initial" \
    cargo test \
      --release \
      --manifest-path runtime/Cargo.toml \
      -p acg-miniwarehouse-workload \
      --test parallelism_metrics \
      -- \
      --nocapture --test-threads=1 | tee "$log"

    grep -E \
      'fresh Wasm pool prep/target/initial:|serial-equivalent work:|actual parallel preexecute:|REALIZED preexec speedup:|dependency-DAG lower bound:|observed-service DAG bound:|worker phase wall:|execution phase wall excl fill:|aggregate ready/lock wait:|scheduler mutex wait:|dependency condvar sleep:|dependency sleep events:|ready-empty observations:|avg ready depth at dispatch:|max ready queue depth:|worker tx min / max:|aggregate visibility capture:|aggregate contract\+receipt:|aggregate publish/unblock:|observed service work sum:|observed service / serial:|execution / observed DAG bound:|wall gap above observed bound:|speculative contract cost / serial:|effective contract concurrency:|worker busy capacity:|worker ready/wait capacity:|max in-flight transactions:|Fresh Wasm instance pool|enabled:|adaptive preparation:|reserved / max-prep / execution threads:|low / high watermark per code:|target per code:|predicted code checksums:|initial fill wall:|aggregate prepare time:|adaptive prepare time:|aggregate pool wait:|aggregate backend rebind:|reserved preparer busy capacity:|adaptive prep-slot busy:|prepared instances:|demand/background prepares:|adaptive prepares / max concurrent:|max available / waiters code:|pool requests:|immediate / waited requests:|consumed / unused instances:|aggregate Wasm pool wait:|aggregate Wasm pool rebind:|aggregate request execution:|aggregate receipt finalization:|aggregate pre-contract setup:|aggregate response processing:|aggregate outcome assembly:|aggregate backend construction:|aggregate Wasm instance acquire:|aggregate Wasm entrypoint:|aggregate Wasm recycle:|aggregate host storage callbacks:|aggregate tx-lock wait in host:|aggregate MVCC storage point:|aggregate MVCC publish:|Wasm instance acquires:|Wasm entrypoint calls:|Wasm cache pinned/mem/fs/miss:|reuse rate:|replay rate:|POST-CONSENSUS SPEEDUP:' \
      "$log" | tee -a "$summary"
    echo | tee -a "$summary"
  done
done

cat <<EOF_SUMMARY | tee -a "$summary"
=== interpretation targets ===
Pool hypothesis:
  - waited requests and aggregate pool wait should keep falling as the steady target grows,
  - initial fill should remain roughly flat because it stays fixed at $INITIAL,
  - demand/background prepare counts show whether the preparer is mostly reacting to starvation or
    using idle periods to maintain the reserve,
  - max available / waiters shows whether the configured reserve is actually being reached and the
    worst instantaneous demand burst seen by a checksum.

Executor diagnosis:
  - dependency-DAG lower bound uses serial per-tx costs,
  - observed-service DAG bound uses actual speculative per-tx service costs but the same dependency DAG,
  - if observed-service bound approaches actual execution wall, per-tx cost inflation/resource
    contention is the main reason theoretical parallelism is not realized,
  - if observed-service bound remains far below wall, inspect scheduler mutex/condvar waits, ready
    depth, worker tx imbalance, and publish/unblock time for lost runnable parallelism.
EOF_SUMMARY

echo "Logs: $OUT_DIR"
echo "Summary: $summary"
