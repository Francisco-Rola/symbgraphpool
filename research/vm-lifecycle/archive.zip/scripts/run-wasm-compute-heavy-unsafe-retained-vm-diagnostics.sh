#!/usr/bin/env bash
set -euo pipefail

# Compute-heavy counterpart to the unsafe retained-VM MiniWarehouse experiment. All 200 transactions
# are independent and execute 262144 deterministic Wasm iterations by default.

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

TXS="${ACG_COMPUTE_TXS:-200}"
WORKERS="${ACG_COMPUTE_WORKERS:-6}"
PHYSICAL_CORES="${ACG_PHYSICAL_CORES:-6}"
REPEATS="${ACG_COMPUTE_RETAINED_REPEATS:-3}"
ITERATIONS="${ACG_COMPUTE_RETAINED_ITERATIONS:-262144}"
MEMORY_WORDS="${ACG_COMPUTE_MEMORY_WORDS:-0}"

if (( WORKERS > PHYSICAL_CORES )); then
  echo "refusing to oversubscribe: workers=$WORKERS exceeds physical-core budget=$PHYSICAL_CORES" >&2
  exit 2
fi

STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_DIR="${ACG_COMPUTE_RETAINED_OUT_DIR:-benchmark-results/wasm-compute-heavy-unsafe-retained-vm-6core/${STAMP}}"
mkdir -p "$OUT_DIR"
summary="$OUT_DIR/summary.txt"
: > "$summary"

fail_with_log() {
  local stage="$1" status="$2" log="$3"
  {
    echo
    echo "ERROR: $stage failed with exit status $status"
    echo "log: $log"
    echo "--- last 100 log lines ---"
    tail -n 100 "$log" 2>/dev/null || true
  } | tee -a "$summary" >&2
  exit "$status"
}

run_capture() {
  local stage="$1" log="$2"
  shift 2
  set +e
  "$@" 2>&1 | tee "$log"
  local status=${PIPESTATUS[0]}
  set -e
  if (( status != 0 )); then
    fail_with_log "$stage" "$status" "$log"
  fi
}

build_log="$OUT_DIR/build-compute-probe.log"
run_capture "compute-probe Wasm build" "$build_log" \
  cargo build \
    --manifest-path benchmarks/Cargo.toml \
    -p acg-wasm-compute-probe \
    --release \
    --target wasm32-unknown-unknown

metadata="$(cargo metadata --manifest-path benchmarks/Cargo.toml --format-version 1 --no-deps 2>/dev/null)"
target_dir="$(printf '%s' "$metadata" | sed -n 's/.*"target_directory":"\([^"]*\)".*/\1/p')"
if [[ -z "$target_dir" ]]; then
  target_dir="benchmarks/target"
fi
COMPUTE_WASM="$target_dir/wasm32-unknown-unknown/release/acg_wasm_compute_probe.wasm"
if [[ ! -s "$COMPUTE_WASM" ]]; then
  echo "ERROR: compute-probe artifact not found after successful build: $COMPUTE_WASM" | tee -a "$summary" >&2
  exit 3
fi

preflight_log="$OUT_DIR/preflight.log"
run_capture "wasm_compute_scaling integration-test compile" "$preflight_log" \
  cargo test \
    --release \
    --manifest-path runtime/Cargo.toml \
    -p acg-cosmwasm-engine \
    --test wasm_compute_scaling \
    --no-run

cat <<EOF_SUMMARY | tee -a "$summary"
=== six-core compute-heavy UNSAFE retained-VM upper-bound experiment ===
WARNING: retained mode is deliberately semantically invalid; dirty VM memory/globals/gas survive across calls.
transactions: $TXS
physical-core / worker budget: $PHYSICAL_CORES / $WORKERS
iterations: $ITERATIONS
memory words: $MEMORY_WORDS
repeats: $REPEATS
modes: fresh retained
fresh pool: disabled in both modes
dependency lanes: $TXS (fully independent)
Wasm artifact: $COMPUTE_WASM

Question:
  If VM acquisition/recycling is already amortized by a compute-heavy transaction, retained reuse should add little speedup; a large gain would instead justify deeper VM-reset/reuse work.

EOF_SUMMARY

for mode in fresh retained; do
  if [[ "$mode" == "retained" ]]; then
    unsafe_reuse=1
  else
    unsafe_reuse=0
  fi
  for repeat in $(seq 1 "$REPEATS"); do
    log="$OUT_DIR/${mode}_repeat-${repeat}.log"
    echo "=== mode=$mode repeat=$repeat ===" | tee -a "$summary"
    set +e
    env \
      ACG_PHYSICAL_CORES="$PHYSICAL_CORES" \
      ACG_COMPUTE_WASM="$COMPUTE_WASM" \
      ACG_COMPUTE_PROBE_KIND=burn \
      ACG_COMPUTE_TXS="$TXS" \
      ACG_COMPUTE_WORKERS="$WORKERS" \
      ACG_COMPUTE_ITERATIONS="$ITERATIONS" \
      ACG_COMPUTE_MEMORY_WORDS="$MEMORY_WORDS" \
      ACG_COMPUTE_STORAGE_READS=0 \
      ACG_COMPUTE_STORAGE_WRITES=0 \
      ACG_COMPUTE_LANES="$TXS" \
      ACG_COMPUTE_POOL_PREPARERS=0 \
      ACG_COMPUTE_POOL_TARGET=0 \
      ACG_COMPUTE_POOL_INITIAL=0 \
      ACG_COMPUTE_POOL_ADAPTIVE=0 \
      ACG_COMPUTE_UNSAFE_REUSE_WASM_INSTANCES="$unsafe_reuse" \
      RUST_BACKTRACE=1 \
      cargo test \
        --release \
        --manifest-path runtime/Cargo.toml \
        -p acg-cosmwasm-engine \
        --test wasm_compute_scaling \
        -- \
        --ignored --nocapture --test-threads=1 compute_scaling_probe 2>&1 | tee "$log"
    status=${PIPESTATUS[0]}
    set -e
    if (( status != 0 )); then
      fail_with_log "compute-heavy $mode probe" "$status" "$log"
    fi
    if ! grep -Fq '=== Wasm compute scaling probe ===' "$log"; then
      fail_with_log "compute-heavy $mode probe produced no diagnostic marker" 4 "$log"
    fi

    grep -E \
      'probe kind:|transactions / lanes:|workers total / execution:|UNSAFE retained VM reuse:|iterations / memory words:|serial wall:|serial tx work sum:|serial-cost DAG bound:|parallel preexecute wall:|parallel execution excl fill:|observed-service DAG bound:|serial / parallel speedup:|theoretical speedup:|execution / observed bound:|aggregate contract\+receipt:|aggregate Wasm pool wait:|aggregate Wasm acquire:|aggregate retained VM rebind:|retained VM reuse/returns:|aggregate Wasm entrypoint:|aggregate Wasm recycle:' \
      "$log" | tee -a "$summary" || true
    echo | tee -a "$summary"
  done
done

echo "Logs: $OUT_DIR"
echo "Summary: $summary"
