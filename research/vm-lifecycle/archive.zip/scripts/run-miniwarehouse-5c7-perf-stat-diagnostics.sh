#!/usr/bin/env bash
set -euo pipefail

# Optional Linux perf-stat comparison for the six-core MiniWarehouse hot path. This complements
# engine timers with hardware/OS counters that can distinguish allocator/cache/scheduler pressure.

WORKERS="${ACG_MW_TOTAL_WORKERS:-6}"
PHYSICAL_CORES="${ACG_PHYSICAL_CORES:-6}"
if (( WORKERS > PHYSICAL_CORES )); then
  echo "refusing to oversubscribe: workers=$WORKERS exceeds physical-core budget=$PHYSICAL_CORES" >&2
  exit 2
fi
if ! command -v perf >/dev/null 2>&1; then
  echo "perf is required for this experiment (install linux perf tools for your kernel)" >&2
  exit 2
fi

WAREHOUSES="${ACG_MW_WAREHOUSES:-16}"
BLOCK_SIZE="${ACG_MW_BLOCK_SIZE:-200}"
TOTAL_TXS="${ACG_MW_TOTAL_TXS:-1000}"
REPEATS="${ACG_MW_PERF_REPEATS:-3}"
INITIAL="${ACG_MW_PERF_INITIAL:-6}"
SOFTEN_AFTER="${ACG_MW_SYMBOLIC_HARD_SOFTEN_AFTER:-8}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_DIR="${ACG_MW_PERF_OUT_DIR:-benchmark-results/miniwarehouse-5c7-perf-stat-6core/${STAMP}}"
mkdir -p "$OUT_DIR"

# name:adaptive:preparers:low:target:initial
CONFIGS=(
  "off:0:0:0:0:0"
  "fixed64:0:1:0:64:$INITIAL"
  "adaptive48:1:1:12:48:$INITIAL"
  "adaptive64:1:1:16:64:$INITIAL"
)

# Compile before perf so compilation does not dominate the counters.
cargo test \
  --release \
  --manifest-path runtime/Cargo.toml \
  -p acg-miniwarehouse-workload \
  --test parallelism_metrics \
  --no-run

summary="$OUT_DIR/summary.txt"
: > "$summary"
cat <<EOF_SUMMARY | tee -a "$summary"
=== six-core MiniWarehouse perf-stat experiment ===
workers / physical cores: $WORKERS / $PHYSICAL_CORES
configs: ${CONFIGS[*]}
perf events: cycles,instructions,cache-references,cache-misses,context-switches,cpu-migrations,page-faults

Compare normalized counters together with engine wall/service metrics. In particular:
  - cache-miss or page-fault growth with aggressive preparation supports VM-memory pressure;
  - context-switch/cpu-migration growth supports scheduler pressure;
  - instructions/cycle growth distinguishes extra actual work from pure waiting.

EOF_SUMMARY

for encoded in "${CONFIGS[@]}"; do
  IFS=: read -r name adaptive preparers low target initial <<<"$encoded"
  for repeat in $(seq 1 "$REPEATS"); do
    log="$OUT_DIR/${name}_repeat-${repeat}.log"
    perf_log="$OUT_DIR/${name}_repeat-${repeat}.perf.csv"
    echo "=== mode=$name repeat=$repeat ===" | tee -a "$summary"
    perf stat -x, \
      -e cycles,instructions,cache-references,cache-misses,context-switches,cpu-migrations,page-faults \
      -o "$perf_log" -- \
      env \
        ACG_MW_WAREHOUSES="$WAREHOUSES" \
        ACG_MW_BLOCK_SIZE="$BLOCK_SIZE" \
        ACG_MW_TOTAL_TXS="$TOTAL_TXS" \
        ACG_MW_TOTAL_WORKERS="$WORKERS" \
        ACG_MW_SYMBOLIC_HARD_SOFTEN_AFTER="$SOFTEN_AFTER" \
        ACG_MW_WASM_POOL_PREPARERS="$preparers" \
        ACG_MW_WASM_POOL_TARGET_PER_CODE="$target" \
        ACG_MW_WASM_POOL_INITIAL_PER_CODE="$initial" \
        ACG_MW_WASM_POOL_ADAPTIVE="$adaptive" \
        ACG_MW_WASM_POOL_LOW_WATERMARK_PER_CODE="$low" \
        cargo test \
          --release \
          --manifest-path runtime/Cargo.toml \
          -p acg-miniwarehouse-workload \
          --test parallelism_metrics \
          -- \
          --nocapture --test-threads=1 | tee "$log"

    grep -E \
      'serial-equivalent work:|actual parallel preexecute:|dependency-DAG lower bound:|observed-service DAG bound:|execution phase wall excl fill:|observed service / serial:|execution / observed DAG bound:|adaptive preparation:|reserved / max-prep / execution threads:|low / high watermark per code:|aggregate prepare time:|adaptive prepare time:|aggregate pool wait:|prepared instances:|consumed / unused instances:|aggregate Wasm entrypoint:|aggregate Wasm recycle:|aggregate host storage callbacks:|aggregate MVCC storage point:' \
      "$log" | tee -a "$summary"
    sed '/^#/d;/^[[:space:]]*$/d' "$perf_log" | tee -a "$summary"
    echo | tee -a "$summary"
  done
done

echo "Logs: $OUT_DIR"
echo "Summary: $summary"
