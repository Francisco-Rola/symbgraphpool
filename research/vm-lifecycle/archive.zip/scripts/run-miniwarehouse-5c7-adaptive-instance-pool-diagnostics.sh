#!/usr/bin/env bash
set -euo pipefail

# Six-core MiniWarehouse comparison of no pool, a permanently reserved preparer, and adaptive
# high/low-watermark preparation. Adaptive mode never creates more than six worker threads: one of
# the six transaction workers temporarily becomes a preparer, then rejoins READY-DAG execution.

WAREHOUSES="${ACG_MW_WAREHOUSES:-16}"
BLOCK_SIZE="${ACG_MW_BLOCK_SIZE:-200}"
TOTAL_TXS="${ACG_MW_TOTAL_TXS:-1000}"
WORKERS="${ACG_MW_TOTAL_WORKERS:-6}"
PHYSICAL_CORES="${ACG_PHYSICAL_CORES:-6}"
if (( WORKERS > PHYSICAL_CORES )); then
  echo "refusing to oversubscribe: workers=$WORKERS exceeds physical-core budget=$PHYSICAL_CORES" >&2
  exit 2
fi
REPEATS="${ACG_MW_ADAPTIVE_REPEATS:-5}"
INITIAL="${ACG_MW_ADAPTIVE_INITIAL:-6}"
SOFTEN_AFTER="${ACG_MW_SYMBOLIC_HARD_SOFTEN_AFTER:-8}"
BLOCK_INTERVAL_MS="${ACG_MW_BLOCK_INTERVAL_MS:-700}"
CONSENSUS_MS="${ACG_MW_CONSENSUS_MS:-700}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_DIR="${ACG_MW_ADAPTIVE_OUT_DIR:-benchmark-results/miniwarehouse-5c7-adaptive-pool-6core/${STAMP}}"
mkdir -p "$OUT_DIR"

# name:adaptive:max-preparers:low:high:initial
CONFIGS=(
  "off:0:0:0:0:0"
  "fixed48:0:1:0:48:$INITIAL"
  "fixed64:0:1:0:64:$INITIAL"
  "adaptive32:1:1:8:32:$INITIAL"
  "adaptive48:1:1:12:48:$INITIAL"
  "adaptive64:1:1:16:64:$INITIAL"
  "adaptive64-low24:1:1:24:64:$INITIAL"
)

summary="$OUT_DIR/summary.txt"
: > "$summary"
cat <<EOF_SUMMARY | tee -a "$summary"
=== six-core MiniWarehouse adaptive fresh-VM pool experiment ===
physical-core / worker budget: $PHYSICAL_CORES / $WORKERS
warehouses: $WAREHOUSES
transactions: $TOTAL_TXS
block size: $BLOCK_SIZE
repeats: $REPEATS
initial fill: $INITIAL
configs: ${CONFIGS[*]}

Questions:
  1. Does adaptive preparation keep all six execution workers available once the reserve is healthy?
  2. Which low/high watermark minimizes pool wait without background overproduction?
  3. Does adaptive mode reduce observed-service inflation versus fixed 5-exec+1-preparer mode?

EOF_SUMMARY

for encoded in "${CONFIGS[@]}"; do
  IFS=: read -r name adaptive preparers low target initial <<<"$encoded"
  for repeat in $(seq 1 "$REPEATS"); do
    log="$OUT_DIR/${name}_repeat-${repeat}.log"
    echo "=== mode=$name repeat=$repeat ===" | tee -a "$summary"
    ACG_MW_WAREHOUSES="$WAREHOUSES" \
    ACG_MW_BLOCK_SIZE="$BLOCK_SIZE" \
    ACG_MW_TOTAL_TXS="$TOTAL_TXS" \
    ACG_MW_TOTAL_WORKERS="$WORKERS" \
    ACG_MW_BLOCK_INTERVAL_MS="$BLOCK_INTERVAL_MS" \
    ACG_MW_CONSENSUS_MS="$CONSENSUS_MS" \
    ACG_MW_SYMBOLIC_HARD_SOFTEN_AFTER="$SOFTEN_AFTER" \
    ACG_MW_WASM_POOL_PREPARERS="$preparers" \
    ACG_MW_WASM_POOL_TARGET_PER_CODE="$target" \
    ACG_MW_WASM_POOL_INITIAL_PER_CODE="$initial" \
    ACG_MW_WASM_POOL_ADAPTIVE="$adaptive" \
    ACG_MW_WASM_POOL_LOW_WATERMARK_PER_CODE="$low" \
    cargo test \
      --release \
      --manifest-path runtime/Cargo.toml \
      -p acg-miniwarehouse-workload \
      --test parallelism_metrics \
      -- \
      --nocapture --test-threads=1 | tee "$log"

    grep -E \
      'serial-equivalent work:|actual parallel preexecute:|dependency-DAG lower bound:|observed-service DAG bound:|REALIZED preexec speedup:|worker phase wall:|execution phase wall excl fill:|scheduler mutex wait:|dependency condvar sleep:|avg ready depth at dispatch:|worker tx min / max:|observed service / serial:|execution / observed DAG bound:|wall gap above observed bound:|effective contract concurrency:|max in-flight transactions:|Fresh Wasm instance pool|enabled:|adaptive preparation:|reserved / max-prep / execution threads:|low / high watermark per code:|initial fill wall:|aggregate prepare time:|adaptive prepare time:|aggregate pool wait:|reserved preparer busy capacity:|adaptive prep-slot busy:|prepared instances:|demand/background prepares:|adaptive prepares / max concurrent:|max available / waiters code:|immediate / waited requests:|consumed / unused instances:|aggregate request execution:|aggregate receipt finalization:|aggregate pre-contract setup:|aggregate response processing:|aggregate outcome assembly:|aggregate backend construction:|aggregate Wasm instance acquire:|aggregate Wasm entrypoint:|aggregate Wasm recycle:|aggregate host storage callbacks:|aggregate tx-lock wait in host:|aggregate MVCC storage point:|aggregate MVCC publish:|host storage get/scan/next/set/remove:|MVCC point version hits:|MVCC point base fallbacks:|reuse rate:|replay rate:' \
      "$log" | tee -a "$summary"
    echo | tee -a "$summary"
  done
done

echo "Logs: $OUT_DIR"
echo "Summary: $summary"
