#!/usr/bin/env bash
set -euo pipefail

# Six-core host-storage/MVCC scaling probe using a dedicated storage-only Wasm contract and
# transaction-unique keys. Cargo stderr/backtraces are preserved in the summary on failure.

TXS="${ACG_STORAGE_PROBE_TXS:-200}"
WORKERS="${ACG_STORAGE_PROBE_WORKERS:-6}"
PHYSICAL_CORES="${ACG_PHYSICAL_CORES:-6}"
if (( WORKERS > PHYSICAL_CORES )); then
  echo "refusing to oversubscribe: workers=$WORKERS exceeds physical-core budget=$PHYSICAL_CORES" >&2
  exit 2
fi
REPEATS="${ACG_STORAGE_PROBE_REPEATS:-3}"
LEVELS="${ACG_STORAGE_PROBE_LEVELS:-1 4 16 64}"
VALUE_BYTES="${ACG_STORAGE_PROBE_VALUE_BYTES:-32}"
INITIAL="${ACG_STORAGE_PROBE_POOL_INITIAL:-6}"
LOW="${ACG_STORAGE_PROBE_POOL_LOW:-12}"
TARGET="${ACG_STORAGE_PROBE_POOL_TARGET:-48}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUT_DIR="${ACG_STORAGE_PROBE_OUT_DIR:-benchmark-results/wasm-host-storage-scaling-6core/${STAMP}}"
mkdir -p "$OUT_DIR"

summary="$OUT_DIR/summary.txt"
: > "$summary"
cat <<EOF_SUMMARY | tee -a "$summary"
=== six-core host storage / MVCC scaling experiment ===
transactions: $TXS
physical-core / worker budget: $PHYSICAL_CORES / $WORKERS
repeats: $REPEATS
operation levels: $LEVELS
write value bytes: $VALUE_BYTES
pool modes: off, adaptive(max-prep=1 low=$LOW high=$TARGET initial=$INITIAL)
keys: transaction-unique (no intentional cross-tx conflicts)
probe: dedicated storage-only Wasm artifact

Interpretation:
  - rising observed-service/serial with read count points at host/MVCC read contention or fixed callback cost;
  - rising tx-lock/MVCC timing with writes points at publication/storage machinery;
  - execution/observed-bound near 1.0 means the scheduler is still realizing the work it is given;
  - compare pool-off vs adaptive to see whether VM preparation materially changes host/MVCC service inflation.

EOF_SUMMARY

fail_with_log() {
  local stage="$1" status="$2" log="$3"
  {
    echo
    echo "ERROR: $stage failed with exit status $status"
    echo "log: $log"
    echo "--- last 80 log lines ---"
    tail -n 80 "$log" 2>/dev/null || true
  } | tee -a "$summary" >&2
  exit "$status"
}

run_capture() {
  local stage="$1" log="$2"
  shift 2
  set +e
  "$@" 2>&1 | tee "$log"
  local status=${PIPESTATUS[0]}
  set -e
  if (( status != 0 )); then
    fail_with_log "$stage" "$status" "$log"
  fi
}

build_log="$OUT_DIR/build-storage-probe.log"
run_capture "storage-probe Wasm build" "$build_log" \
  cargo build \
    --manifest-path benchmarks/Cargo.toml \
    -p acg-wasm-storage-probe \
    --release \
    --target wasm32-unknown-unknown

metadata="$(cargo metadata --manifest-path benchmarks/Cargo.toml --format-version 1 --no-deps 2>/dev/null)"
target_dir="$(printf '%s' "$metadata" | sed -n 's/.*"target_directory":"\([^"]*\)".*/\1/p')"
if [[ -z "$target_dir" ]]; then
  target_dir="benchmarks/target"
fi
STORAGE_WASM="$target_dir/wasm32-unknown-unknown/release/acg_wasm_storage_probe.wasm"
if [[ ! -s "$STORAGE_WASM" ]]; then
  echo "ERROR: storage-probe artifact not found after successful build: $STORAGE_WASM" | tee -a "$summary" >&2
  exit 3
fi
echo "storage probe artifact: $STORAGE_WASM" | tee -a "$summary"
echo | tee -a "$summary"

preflight_log="$OUT_DIR/preflight-wasm-compute-scaling.log"
run_capture "wasm_compute_scaling integration-test compile" "$preflight_log" \
  cargo test \
    --release \
    --manifest-path runtime/Cargo.toml \
    -p acg-cosmwasm-engine \
    --test wasm_compute_scaling \
    --no-run

run_probe() {
  local log="$1"
  shift
  set +e
  env "$@" \
    ACG_PHYSICAL_CORES="$PHYSICAL_CORES" \
    ACG_COMPUTE_WASM="$STORAGE_WASM" \
    ACG_COMPUTE_PROBE_KIND=storage \
    RUST_BACKTRACE=1 \
    cargo test \
      --release \
      --manifest-path runtime/Cargo.toml \
      -p acg-cosmwasm-engine \
      --test wasm_compute_scaling \
      -- \
      --ignored --nocapture --test-threads=1 compute_scaling_probe 2>&1 | tee "$log"
  local status=${PIPESTATUS[0]}
  set -e
  if (( status != 0 )); then
    fail_with_log "host-storage probe" "$status" "$log"
  fi
  if ! grep -Fq '=== Wasm compute scaling probe ===' "$log"; then
    fail_with_log "host-storage probe produced no diagnostic marker" 4 "$log"
  fi
}

run_case() {
  local label="$1" reads="$2" writes="$3" mode="$4" repeat="$5"
  local preparers=0 target=0 initial=0 adaptive=0 low=0
  if [[ "$mode" == "adaptive-pool" ]]; then
    preparers=1; target="$TARGET"; initial="$INITIAL"; adaptive=1; low="$LOW"
  fi
  local log="$OUT_DIR/${label}_${mode}_repeat-${repeat}.log"
  echo "=== case=$label mode=$mode repeat=$repeat ===" | tee -a "$summary"
  run_probe "$log" \
    ACG_COMPUTE_TXS="$TXS" \
    ACG_COMPUTE_WORKERS="$WORKERS" \
    ACG_COMPUTE_ITERATIONS=0 \
    ACG_COMPUTE_MEMORY_WORDS=0 \
    ACG_COMPUTE_STORAGE_READS="$reads" \
    ACG_COMPUTE_STORAGE_WRITES="$writes" \
    ACG_COMPUTE_STORAGE_VALUE_BYTES="$VALUE_BYTES" \
    ACG_COMPUTE_LANES="$TXS" \
    ACG_COMPUTE_POOL_PREPARERS="$preparers" \
    ACG_COMPUTE_POOL_TARGET="$target" \
    ACG_COMPUTE_POOL_INITIAL="$initial" \
    ACG_COMPUTE_POOL_ADAPTIVE="$adaptive" \
    ACG_COMPUTE_POOL_LOW_WATERMARK="$low"

  grep -E \
    'probe kind:|transactions / lanes:|workers total / execution:|pool adaptive / low watermark:|storage reads/writes/value B:|serial wall:|serial-cost DAG bound:|parallel preexecute wall:|parallel execution excl fill:|observed-service DAG bound:|serial / parallel speedup:|theoretical speedup:|execution / observed bound:|aggregate contract\+receipt:|aggregate Wasm pool wait:|aggregate Wasm entrypoint:|aggregate Wasm recycle:|aggregate host storage:|aggregate tx-lock wait:|aggregate MVCC point:|aggregate MVCC publish:|host get/set \+ MVCC reads:|pool immediate / waited:|pool unused instances:' \
    "$log" | tee -a "$summary" || true
  echo | tee -a "$summary"
}

for mode in off adaptive-pool; do
  for repeat in $(seq 1 "$REPEATS"); do
    run_case baseline 0 0 "$mode" "$repeat"
  done
  for level in $LEVELS; do
    for repeat in $(seq 1 "$REPEATS"); do
      run_case "reads-${level}" "$level" 0 "$mode" "$repeat"
      run_case "writes-${level}" 0 "$level" "$mode" "$repeat"
    done
  done
done

echo "Logs: $OUT_DIR"
echo "Summary: $summary"
