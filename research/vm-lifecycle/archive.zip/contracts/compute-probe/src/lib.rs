//! Storage-free CosmWasm compute probe used to measure READY-DAG scaling as useful Wasm work grows.
//!
//! The accumulator is returned to the host so LLVM cannot remove the loop. `memory_words` adds a
//! controllable linear-memory working set without introducing host storage or query callbacks.

use cosmwasm_std::{entry_point, to_json_binary, DepsMut, Empty, Env, MessageInfo, Response, StdResult};
use serde::{Deserialize, Serialize};

#[derive(Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ExecuteMsg {
    Burn {
        iterations: u64,
        seed: u64,
        memory_words: u32,
    },
}

#[derive(Serialize)]
pub struct BurnResult {
    pub accumulator: u64,
}

#[entry_point]
pub fn instantiate(
    _deps: DepsMut,
    _env: Env,
    _info: MessageInfo,
    _msg: Empty,
) -> StdResult<Response> {
    Ok(Response::new().add_attribute("action", "instantiate"))
}

#[entry_point]
pub fn execute(
    _deps: DepsMut,
    _env: Env,
    _info: MessageInfo,
    msg: ExecuteMsg,
) -> StdResult<Response> {
    match msg {
        ExecuteMsg::Burn {
            iterations,
            seed,
            memory_words,
        } => execute_burn(iterations, seed, memory_words),
    }
}

fn execute_burn(iterations: u64, seed: u64, memory_words: u32) -> StdResult<Response> {
    let mut accumulator = seed ^ 0x9E37_79B9_7F4A_7C15;
    let mut scratch = vec![0_u64; memory_words as usize];

    for iteration in 0..iterations {
        let mixed = iteration
            .wrapping_add(accumulator.rotate_left(17))
            .wrapping_mul(0xD6E8_FEB8_6659_FD93);
        accumulator ^= mixed.rotate_right(((iteration >> 3) & 63) as u32);
        accumulator = accumulator
            .wrapping_mul(0xA076_1D64_78BD_642F)
            .wrapping_add(0xE703_7ED1_A0B4_28DB);

        if !scratch.is_empty() {
            let index = (accumulator as usize) % scratch.len();
            let prior = scratch[index];
            let next = prior
                .wrapping_add(accumulator)
                .rotate_left(((iteration >> 5) & 63) as u32);
            scratch[index] = next;
            accumulator ^= next;
        }
    }

    // Fold the memory working set back into the returned value so its accesses remain observable.
    for word in scratch {
        accumulator = accumulator.rotate_left(7) ^ word.wrapping_mul(0x94D0_49BB_1331_11EB);
    }

    Ok(Response::new()
        .add_attribute("action", "burn")
        .set_data(to_json_binary(&BurnResult { accumulator })?))
}
