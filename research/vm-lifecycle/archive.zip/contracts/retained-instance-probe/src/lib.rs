//! Purpose-built CosmWasm contract for retained-VM isolation experiments.
//!
//! This contract deliberately keeps process-local state in Wasm linear memory. A fresh Wasm
//! instance must start with the zero-initialized values below, while reusing one retained instance
//! across independent transactions will reveal whether that VM-local state survives between calls.

use cosmwasm_std::{
    entry_point, to_json_binary, DepsMut, Empty, Env, MessageInfo, Response, StdError, StdResult, Uint128,
};
use serde::{Deserialize, Serialize};

const MARKER_KEY: &[u8] = b"marker";
const PROBE_ACCOUNT: &str = "probe-account";
const PROBE_DENOM: &str = "utest";
const SENTINEL_VALUE: u8 = 0xA5;

// Deliberately not chain state. These values live in the Wasm instance's linear memory and exist
// only to expose whether a retained instance carries VM-local state from one transaction to the
// next. Production contracts must never rely on this behavior.
static mut VM_COUNTER: u32 = 0;
static mut VM_SENTINEL: u8 = 0;

#[derive(Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ExecuteMsg {
    Probe { leak_bytes: u32 },
}

#[derive(Serialize)]
pub struct ProbeObservation {
    pub counter_before: u32,
    pub sentinel_before: u8,
    pub backend_marker: String,
    pub backend_balance: Uint128,
}

#[entry_point]
pub fn instantiate(
    _deps: DepsMut,
    _env: Env,
    _info: MessageInfo,
    _msg: Empty,
) -> StdResult<Response> {
    Ok(Response::new().add_attribute("action", "instantiate"))
}

#[entry_point]
pub fn execute(
    deps: DepsMut,
    _env: Env,
    _info: MessageInfo,
    msg: ExecuteMsg,
) -> StdResult<Response> {
    match msg {
        ExecuteMsg::Probe { leak_bytes } => execute_probe(deps, leak_bytes),
    }
}

fn execute_probe(deps: DepsMut, leak_bytes: u32) -> StdResult<Response> {
    // SAFETY: CosmWasm executes one entrypoint at a time within one Wasm instance. These statics
    // are intentionally used only as an isolation probe. The test expects a retained instance to
    // preserve them and a newly instantiated VM to reset them to their module initializers.
    let (counter_before, sentinel_before) = unsafe {
        let counter_before = VM_COUNTER;
        let sentinel_before = VM_SENTINEL;
        VM_COUNTER = VM_COUNTER.saturating_add(1);
        VM_SENTINEL = SENTINEL_VALUE;
        (counter_before, sentinel_before)
    };

    let backend_marker = deps
        .storage
        .get(MARKER_KEY)
        .map(String::from_utf8)
        .transpose()
        .map_err(|error| StdError::generic_err(format!("invalid marker UTF-8: {error}")))?
        .unwrap_or_default();
    let backend_balance = deps
        .querier
        .query_balance(PROBE_ACCOUNT, PROBE_DENOM)?
        .amount;

    // Force unmistakable retained linear-memory pressure. `forget` is deliberate: a fresh VM
    // discards this allocation with the instance, while a retained VM cannot reclaim it through
    // the contract allocator. The host experiment also samples `Instance::memory_pages()`.
    if leak_bytes != 0 {
        let leaked = vec![0x5A_u8; leak_bytes as usize];
        std::mem::forget(leaked);
    }

    let observation = ProbeObservation {
        counter_before,
        sentinel_before,
        backend_marker,
        backend_balance,
    };
    Ok(Response::new()
        .add_attribute("action", "probe")
        .set_data(to_json_binary(&observation)?))
}
