//! Storage-only CosmWasm probe used to isolate host storage callback and speculative MVCC costs.
//!
//! Every transaction receives a distinct `seed`, and every key includes that seed. Different
//! transactions therefore touch disjoint contract-storage keys unless a caller deliberately reuses
//! a seed. This lets the benchmark scale host reads/writes without introducing intended conflicts.

use cosmwasm_std::{entry_point, to_json_binary, DepsMut, Empty, Env, MessageInfo, Response, StdResult};
use serde::{Deserialize, Serialize};

#[derive(Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ExecuteMsg {
    Storage {
        reads: u32,
        writes: u32,
        seed: u64,
        value_bytes: u32,
    },
}

#[derive(Serialize)]
pub struct StorageResult {
    pub accumulator: u64,
}

#[entry_point]
pub fn instantiate(
    _deps: DepsMut,
    _env: Env,
    _info: MessageInfo,
    _msg: Empty,
) -> StdResult<Response> {
    Ok(Response::new().add_attribute("action", "instantiate"))
}

#[entry_point]
pub fn execute(
    deps: DepsMut,
    _env: Env,
    _info: MessageInfo,
    msg: ExecuteMsg,
) -> StdResult<Response> {
    match msg {
        ExecuteMsg::Storage {
            reads,
            writes,
            seed,
            value_bytes,
        } => execute_storage(deps, reads, writes, seed, value_bytes),
    }
}

fn execute_storage(
    deps: DepsMut,
    reads: u32,
    writes: u32,
    seed: u64,
    value_bytes: u32,
) -> StdResult<Response> {
    let mut accumulator = seed ^ 0xA076_1D64_78BD_642F;

    for index in 0..reads {
        let key = format!("probe/read/{seed}/{index}").into_bytes();
        match deps.storage.get(&key) {
            Some(value) => {
                for byte in value {
                    accumulator = accumulator.rotate_left(5) ^ u64::from(byte);
                }
            }
            None => {
                accumulator ^= u64::from(index).wrapping_mul(0x9E37_79B9);
            }
        }
    }

    let value_len = value_bytes.max(1) as usize;
    let mut value = vec![seed as u8; value_len];
    for index in 0..writes {
        let key = format!("probe/write/{seed}/{index}").into_bytes();
        let fill = accumulator.wrapping_add(u64::from(index)) as u8;
        value[0] = fill;
        deps.storage.set(&key, &value);
        accumulator = accumulator.rotate_left(9) ^ u64::from(fill);
    }

    Ok(Response::new()
        .add_attribute("action", "storage")
        .set_data(to_json_binary(&StorageResult { accumulator })?))
}
