use std::env;
use std::fs;
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};

use acg_cosmwasm_engine::{
    Address, BlockContext, CanonicalTransaction, CosmWasmEngine, EngineConfig, ExecutionRequest,
    ParallelExecutionConfig, SpeculativeDependency, SpeculativeDependencyClass, SpeculativeWave,
    TransactionId, WasmInstancePoolConfig,
};
use cosmwasm_std::Binary;
use serde_json::json;

const INSTANTIATE_TX_ID: u64 = 900_100;
const TX_ID_BASE: u64 = 1_000_000;
const DEFAULT_COMPUTE_WASM_RELATIVE_PATH: &str =
    "benchmarks/target/wasm32-unknown-unknown/release/acg_wasm_compute_probe.wasm";
const DEFAULT_STORAGE_WASM_RELATIVE_PATH: &str =
    "benchmarks/target/wasm32-unknown-unknown/release/acg_wasm_storage_probe.wasm";

fn repository_root() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR"))
        .join("../../..")
        .canonicalize()
        .expect("failed to resolve repository root")
}

fn env_usize(name: &str, default: usize) -> usize {
    env::var(name)
        .ok()
        .map(|value| value.parse::<usize>().unwrap_or_else(|_| panic!("invalid {name}={value}")))
        .unwrap_or(default)
}

fn env_u64(name: &str, default: u64) -> u64 {
    env::var(name)
        .ok()
        .map(|value| value.parse::<u64>().unwrap_or_else(|_| panic!("invalid {name}={value}")))
        .unwrap_or(default)
}

fn load_probe_wasm(probe_kind: &str) -> (PathBuf, Vec<u8>) {
    let default_relative_path = match probe_kind {
        "burn" => DEFAULT_COMPUTE_WASM_RELATIVE_PATH,
        "storage" => DEFAULT_STORAGE_WASM_RELATIVE_PATH,
        other => panic!("invalid ACG_COMPUTE_PROBE_KIND={other}; expected burn or storage"),
    };
    let path = env::var_os("ACG_COMPUTE_WASM")
        .map(PathBuf::from)
        .unwrap_or_else(|| repository_root().join(default_relative_path));
    let wasm = fs::read(&path).unwrap_or_else(|error| {
        panic!(
            "failed to read {probe_kind} probe Wasm at {}: {error}; set ACG_COMPUTE_WASM to the artifact built by the diagnostic script",
            path.display()
        )
    });
    (path, wasm)
}

fn setup_engine(
    wasm: &[u8],
    pool: WasmInstancePoolConfig,
    wasm_fresh_instance_cache_shards: usize,
    unsafe_reuse_wasm_instances: bool,
) -> (CosmWasmEngine, Address) {
    let engine = CosmWasmEngine::new(EngineConfig {
        wasm_instance_pool: pool,
        wasm_fresh_instance_cache_shards,
        unsafe_reuse_wasm_instances,
        ..EngineConfig::default()
    });
    let code_id = engine.upload_wasm(wasm.to_vec()).unwrap();
    let contract = engine
        .instantiate(
            TransactionId(INSTANTIATE_TX_ID),
            BlockContext::default(),
            Address::from("compute-sender"),
            code_id,
            None,
            "compute-probe".to_owned(),
            Vec::new(),
            Binary::from(b"{}".as_slice()),
        )
        .unwrap()
        .contract;
    (engine, contract)
}

fn transactions(
    contract: &Address,
    count: usize,
    iterations: u64,
    memory_words: u32,
    storage_reads: u32,
    storage_writes: u32,
    storage_value_bytes: u32,
    storage_mode: bool,
) -> Vec<CanonicalTransaction> {
    (0..count)
        .map(|index| {
            let transaction_id = TransactionId(TX_ID_BASE + index as u64);
            CanonicalTransaction::new(
                BlockContext {
                    transaction_index: Some(index as u32),
                    ..BlockContext::default()
                },
                ExecutionRequest::Execute {
                    transaction_id,
                    sender: Address::from("compute-sender"),
                    contract: contract.clone(),
                    funds: Vec::new(),
                    msg: Binary::from(
                        serde_json::to_vec(&if storage_mode {
                            json!({
                                "storage": {
                                    "reads": storage_reads,
                                    "writes": storage_writes,
                                    "seed": index as u64 + 1,
                                    "value_bytes": storage_value_bytes,
                                }
                            })
                        } else {
                            json!({
                                "burn": {
                                    "iterations": iterations,
                                    "seed": index as u64 + 1,
                                    "memory_words": memory_words,
                                }
                            })
                        })
                        .unwrap(),
                    ),
                },
            )
        })
        .collect()
}

fn dependency_plan(
    transactions: &[CanonicalTransaction],
    lanes: usize,
) -> (Vec<SpeculativeWave>, Vec<SpeculativeDependency>) {
    let lane_count = lanes.max(1).min(transactions.len().max(1));
    let ids = transactions
        .iter()
        .map(CanonicalTransaction::transaction_id)
        .collect::<Vec<_>>();
    let waves = ids
        .chunks(lane_count)
        .map(|chunk| SpeculativeWave::new(chunk.to_vec()))
        .collect::<Vec<_>>();
    let dependencies = (lane_count..ids.len())
        .map(|index| SpeculativeDependency {
            predecessor: ids[index - lane_count],
            successor: ids[index],
            class: SpeculativeDependencyClass::Hard,
        })
        .collect::<Vec<_>>();
    (waves, dependencies)
}

fn controlled_dag_bound(per_tx: &[Duration], lanes: usize, workers: usize) -> Duration {
    if per_tx.is_empty() || workers == 0 {
        return Duration::ZERO;
    }
    let lane_count = lanes.max(1).min(per_tx.len());
    let total_work = per_tx.iter().map(Duration::as_secs_f64).sum::<f64>();
    let worker_bound = total_work / workers as f64;
    let mut lane_finish = vec![0.0_f64; lane_count];
    for (index, duration) in per_tx.iter().enumerate() {
        let lane = index % lane_count;
        lane_finish[lane] += duration.as_secs_f64();
    }
    let dependency_bound = lane_finish.into_iter().fold(0.0_f64, f64::max);
    Duration::from_secs_f64(worker_bound.max(dependency_bound))
}

#[test]
#[ignore = "diagnostic experiment; requires the separately built acg-wasm-compute-probe Wasm"]
fn compute_scaling_probe() {
    let tx_count = env_usize("ACG_COMPUTE_TXS", 200).max(1);
    let workers = env_usize("ACG_COMPUTE_WORKERS", 6).max(1);
    let physical_cores = env_usize("ACG_PHYSICAL_CORES", 6).max(1);
    assert!(
        workers <= physical_cores,
        "ACG_COMPUTE_WORKERS={workers} exceeds ACG_PHYSICAL_CORES={physical_cores}"
    );
    let iterations = env_u64("ACG_COMPUTE_ITERATIONS", 0);
    let memory_words = env_usize("ACG_COMPUTE_MEMORY_WORDS", 0) as u32;
    let storage_reads = env_usize("ACG_COMPUTE_STORAGE_READS", 0) as u32;
    let storage_writes = env_usize("ACG_COMPUTE_STORAGE_WRITES", 0) as u32;
    let storage_value_bytes = env_usize("ACG_COMPUTE_STORAGE_VALUE_BYTES", 32) as u32;
    let probe_kind = env::var("ACG_COMPUTE_PROBE_KIND").unwrap_or_else(|_| {
        if storage_reads > 0 || storage_writes > 0 {
            "storage".to_owned()
        } else {
            "burn".to_owned()
        }
    });
    let storage_mode = match probe_kind.as_str() {
        "burn" => false,
        "storage" => true,
        other => panic!("invalid ACG_COMPUTE_PROBE_KIND={other}; expected burn or storage"),
    };
    let lanes = env_usize("ACG_COMPUTE_LANES", tx_count).max(1).min(tx_count);
    let preparers = env_usize("ACG_COMPUTE_POOL_PREPARERS", 1);
    let target = env_usize("ACG_COMPUTE_POOL_TARGET", tx_count);
    let initial = env_usize("ACG_COMPUTE_POOL_INITIAL", workers.min(tx_count));
    let adaptive = env_usize("ACG_COMPUTE_POOL_ADAPTIVE", 0) != 0;
    let low_watermark = env_usize("ACG_COMPUTE_POOL_LOW_WATERMARK", initial);
    let pool = if preparers == 0 || target == 0 {
        WasmInstancePoolConfig::default()
    } else {
        WasmInstancePoolConfig {
            preparer_threads: preparers,
            target_per_code: target,
            initial_per_code: initial.min(target),
            adaptive_preparation: adaptive,
            low_watermark_per_code: low_watermark.min(target),
        }
    };

    let wasm_fresh_instance_cache_shards =
        env_usize("ACG_COMPUTE_FRESH_VM_CACHE_SHARDS", 0);
    let unsafe_reuse_wasm_instances =
        env_usize("ACG_COMPUTE_UNSAFE_REUSE_WASM_INSTANCES", 0) != 0;
    assert!(
        !(unsafe_reuse_wasm_instances && pool.enabled()),
        "unsafe retained VM reuse must be measured with the fresh instance pool disabled"
    );
    assert!(
        !(wasm_fresh_instance_cache_shards > 0 && pool.enabled()),
        "fresh VM cache sharding must be measured with the fresh instance pool disabled"
    );
    assert!(
        !(wasm_fresh_instance_cache_shards > 0 && unsafe_reuse_wasm_instances),
        "fresh VM cache sharding and unsafe retained VM reuse are mutually exclusive"
    );

    let (wasm_path, wasm) = load_probe_wasm(&probe_kind);
    let (serial_engine, serial_contract) =
        setup_engine(&wasm, WasmInstancePoolConfig::default(), 0, false);
    let (parallel_engine, parallel_contract) = setup_engine(
        &wasm,
        pool.clone(),
        wasm_fresh_instance_cache_shards,
        unsafe_reuse_wasm_instances,
    );
    let serial_transactions = transactions(
        &serial_contract,
        tx_count,
        iterations,
        memory_words,
        storage_reads,
        storage_writes,
        storage_value_bytes,
        storage_mode,
    );
    let parallel_transactions = transactions(
        &parallel_contract,
        tx_count,
        iterations,
        memory_words,
        storage_reads,
        storage_writes,
        storage_value_bytes,
        storage_mode,
    );
    let (waves, dependencies) = dependency_plan(&parallel_transactions, lanes);

    let mut serial_tx_times = Vec::with_capacity(tx_count);
    let mut serial_outcomes = Vec::with_capacity(tx_count);
    let serial_started = Instant::now();
    for transaction in serial_transactions {
        let tx_started = Instant::now();
        let outcome = serial_engine
            .execute_request(transaction.block, transaction.request)
            .unwrap();
        serial_tx_times.push(tx_started.elapsed());
        serial_outcomes.push(outcome);
    }
    let serial_wall = serial_started.elapsed();

    let transactions_for_preexecute = parallel_transactions.clone();
    let parallel_started = Instant::now();
    let prepared = parallel_engine
        .preexecute_dependency_plan(
            ParallelExecutionConfig { workers },
            transactions_for_preexecute,
            waves,
            dependencies,
        )
        .unwrap();
    let parallel_wall = parallel_started.elapsed();
    let diagnostics = prepared.metrics.dependency_diagnostics.clone();
    let pool_metrics = diagnostics.wasm_instance_pool;
    let execution_workers = if pool_metrics.enabled {
        pool_metrics.execution_threads
    } else {
        workers.min(tx_count)
    };
    let serial_work = serial_tx_times
        .iter()
        .copied()
        .fold(Duration::ZERO, |total, duration| total + duration);
    let serial_cost_bound = controlled_dag_bound(&serial_tx_times, lanes, execution_workers);
    let observed_service_bound = controlled_dag_bound(
        &diagnostics.transaction_service_times,
        lanes,
        execution_workers,
    );
    let execution_wall = diagnostics
        .worker_phase_wall
        .saturating_sub(pool_metrics.initial_fill_wall);
    let speedup = if parallel_wall.is_zero() {
        0.0
    } else {
        serial_wall.as_secs_f64() / parallel_wall.as_secs_f64()
    };
    let theoretical_speedup = if serial_cost_bound.is_zero() {
        0.0
    } else {
        serial_wall.as_secs_f64() / serial_cost_bound.as_secs_f64()
    };
    let observed_bound_ratio = if observed_service_bound.is_zero() {
        0.0
    } else {
        execution_wall.as_secs_f64() / observed_service_bound.as_secs_f64()
    };
    let average_ready_depth = if diagnostics.dispatch_ready_depth_samples == 0 {
        0.0
    } else {
        diagnostics.dispatch_ready_depth_sum as f64
            / diagnostics.dispatch_ready_depth_samples as f64
    };

    let outcome = parallel_engine
        .reconcile_prepared_block(parallel_transactions, prepared)
        .unwrap();
    assert_eq!(outcome.speculative.replayed_transactions, 0);
    assert_eq!(outcome.speculative.reused_results, tx_count as u64);
    for (serial, parallel) in serial_outcomes.iter().zip(&outcome.transactions) {
        let parallel = parallel.result.as_ref().unwrap();
        assert_eq!(serial.transaction_id, parallel.transaction_id);
        assert_eq!(serial.contract, parallel.contract);
        assert_eq!(serial.events, parallel.events);
        assert_eq!(serial.data, parallel.data);
        assert_eq!(serial.created_contracts, parallel.created_contracts);
    }

    println!("=== Wasm compute scaling probe ===");
    println!("probe kind:                    {}", probe_kind);
    println!("Wasm artifact:                 {}", wasm_path.display());
    println!("transactions / lanes:          {} / {}", tx_count, lanes);
    println!("workers total / execution:     {} / {}", workers, execution_workers);
    println!(
        "pool prep/target/initial:       {}/{}/{}",
        pool.preparer_threads, pool.target_per_code, pool.initial_per_code
    );
    println!("iterations / memory words:     {} / {}", iterations, memory_words);
    println!(
        "storage reads/writes/value B:   {} / {} / {}",
        storage_reads, storage_writes, storage_value_bytes
    );
    println!(
        "pool adaptive / low watermark: {} / {}",
        pool.adaptive_preparation, pool.low_watermark_per_code
    );
    println!("fresh VM cache shards:          {wasm_fresh_instance_cache_shards}");
    println!("UNSAFE retained VM reuse:       {unsafe_reuse_wasm_instances}");
    println!("serial wall:                   {:>10.3} ms", serial_wall.as_secs_f64() * 1e3);
    println!("serial tx work sum:            {:>10.3} ms", serial_work.as_secs_f64() * 1e3);
    println!("serial-cost DAG bound:         {:>10.3} ms", serial_cost_bound.as_secs_f64() * 1e3);
    println!("parallel preexecute wall:      {:>10.3} ms", parallel_wall.as_secs_f64() * 1e3);
    println!("parallel execution excl fill:  {:>10.3} ms", execution_wall.as_secs_f64() * 1e3);
    println!("observed-service DAG bound:    {:>10.3} ms", observed_service_bound.as_secs_f64() * 1e3);
    println!("serial / parallel speedup:     {:>10.2}x", speedup);
    println!("theoretical speedup:           {:>10.2}x", theoretical_speedup);
    println!("execution / observed bound:    {:>10.2}x", observed_bound_ratio);
    println!("scheduler mutex wait:          {:>10.3} ms", diagnostics.aggregate_scheduler_lock_wait.as_secs_f64() * 1e3);
    println!("dependency condvar sleep:      {:>10.3} ms", diagnostics.aggregate_scheduler_condvar_wait.as_secs_f64() * 1e3);
    println!("dependency sleep events:       {}", diagnostics.scheduler_condvar_waits);
    println!("avg / max ready depth:         {:.2} / {}", average_ready_depth, diagnostics.max_ready_queue_depth);
    println!("worker tx min / max:           {} / {}", diagnostics.min_transactions_per_worker, diagnostics.max_transactions_per_worker);
    println!("aggregate contract+receipt:    {:>10.3} ms", diagnostics.aggregate_contract_execution.as_secs_f64() * 1e3);
    println!("aggregate Wasm pool wait:      {:>10.3} ms", diagnostics.contract.aggregate_wasm_pool_wait.as_secs_f64() * 1e3);
    println!("aggregate Wasm acquire:        {:>10.3} ms", diagnostics.contract.aggregate_wasm_instance_acquire.as_secs_f64() * 1e3);
    println!("fresh-cache-shard acquires:     {}", diagnostics.contract.wasm_fresh_cache_shard_acquires);
    println!("aggregate retained VM rebind:  {:>10.3} ms", diagnostics.contract.aggregate_wasm_retained_rebind.as_secs_f64() * 1e3);
    println!("retained VM reuse/returns:      {} / {}", diagnostics.contract.wasm_retained_reuses, diagnostics.contract.wasm_retained_returns);
    println!("aggregate Wasm entrypoint:     {:>10.3} ms", diagnostics.contract.aggregate_wasm_entrypoint.as_secs_f64() * 1e3);
    println!("aggregate Wasm recycle:        {:>10.3} ms", diagnostics.contract.aggregate_wasm_recycle.as_secs_f64() * 1e3);
    println!("aggregate host storage:        {:>10.3} ms", diagnostics.contract.aggregate_host_storage.as_secs_f64() * 1e3);
    println!("aggregate tx-lock wait:        {:>10.3} ms", diagnostics.contract.aggregate_transaction_lock_wait.as_secs_f64() * 1e3);
    println!("aggregate MVCC point:          {:>10.3} ms", diagnostics.contract.aggregate_mvcc_storage_point.as_secs_f64() * 1e3);
    println!("aggregate MVCC publish:        {:>10.3} ms", diagnostics.contract.aggregate_mvcc_publish.as_secs_f64() * 1e3);
    println!(
        "host get/set + MVCC reads:      {} / {} / {}",
        diagnostics.contract.host_storage_gets,
        diagnostics.contract.host_storage_sets,
        diagnostics.contract.mvcc_storage_point_reads
    );
    println!("pool immediate / waited:       {} / {}", pool_metrics.immediate_hits, pool_metrics.waited_requests);
    println!("pool max available / waiters:  {} / {}", pool_metrics.max_available_per_code, pool_metrics.max_waiters_per_code);
    println!("pool unused instances:         {}", pool_metrics.unused_instances);
}
