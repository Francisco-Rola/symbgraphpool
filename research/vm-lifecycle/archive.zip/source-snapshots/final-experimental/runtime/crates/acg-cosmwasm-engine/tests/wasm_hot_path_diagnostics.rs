use acg_cosmwasm_engine::{
    Address, BlockContext, CanonicalTransaction, CosmWasmEngine, EngineConfig, ExecutionRequest,
    ParallelExecutionConfig, SpeculativeWave, TransactionId, WasmInstancePoolConfig,
};
use base64::{engine::general_purpose::STANDARD, Engine as _};
use cosmwasm_std::{to_json_binary, Binary, Coin};
use serde_json::json;

const HACKATOM_BASE64: &str = include_str!("../testdata/hackatom_1.2.wasm.b64");

#[test]
fn dependency_preexecution_reports_wasm_and_host_hot_path_activity() {
    let engine = CosmWasmEngine::default();
    engine
        .set_balance("verifier", &[Coin::new(250_u128, "utest")])
        .unwrap();
    let compact: String = HACKATOM_BASE64.split_whitespace().collect();
    let wasm = STANDARD.decode(compact).unwrap();
    let code_id = engine.upload_wasm(wasm).unwrap();
    let contract = engine
        .instantiate(
            TransactionId(1),
            BlockContext::default(),
            Address::from("verifier"),
            code_id,
            None,
            "diagnostic-hackatom".to_owned(),
            vec![Coin::new(100_u128, "utest")],
            to_json_binary(&json!({
                "verifier": "verifier",
                "beneficiary": "beneficiary"
            }))
            .unwrap(),
        )
        .unwrap()
        .contract;

    let request = ExecutionRequest::Execute {
        transaction_id: TransactionId(2),
        sender: Address::from("verifier"),
        contract,
        funds: Vec::new(),
        msg: Binary::from(br#"{"release":{}}"#.as_slice()),
    };
    let transaction = CanonicalTransaction::new(
        BlockContext {
            transaction_index: Some(0),
            ..BlockContext::default()
        },
        request,
    );

    let prepared = engine
        .preexecute_dependency_plan(
            ParallelExecutionConfig { workers: 1 },
            vec![transaction.clone()],
            vec![SpeculativeWave::new(vec![TransactionId(2)])],
            Vec::new(),
        )
        .unwrap();

    let diagnostics = &prepared.metrics.dependency_diagnostics.contract;
    assert_eq!(diagnostics.wasm_instance_acquires, 1);
    assert_eq!(diagnostics.wasm_entrypoint_calls, 1);
    assert_eq!(diagnostics.wasm_instance_recycles, 1);
    assert!(diagnostics.wasm_cache_pinned_hits >= 1);
    assert_eq!(diagnostics.wasm_cache_misses, 0);
    assert!(diagnostics.host_storage_gets > 0);
    assert!(diagnostics.mvcc_storage_point_reads > 0);
    assert!(diagnostics.receipt_access_records > 0);
    assert!(diagnostics.receipt_read_dependencies > 0);

    let outcome = engine
        .reconcile_prepared_block(vec![transaction], prepared)
        .unwrap();
    assert_eq!(outcome.speculative.reused_results, 1);
    assert_eq!(outcome.speculative.replayed_transactions, 0);
}


#[test]
fn fresh_instance_pool_prepares_one_use_instances_and_preserves_reconciliation() {
    let engine = CosmWasmEngine::new(EngineConfig {
        wasm_instance_pool: WasmInstancePoolConfig {
            preparer_threads: 1,
            target_per_code: 2,
            initial_per_code: 2,
            ..WasmInstancePoolConfig::default()
        },
        ..EngineConfig::default()
    });
    engine
        .set_balance("verifier", &[Coin::new(500_u128, "utest")])
        .unwrap();
    let compact: String = HACKATOM_BASE64.split_whitespace().collect();
    let wasm = STANDARD.decode(compact).unwrap();
    let code_id = engine.upload_wasm(wasm).unwrap();

    let contract_a = engine
        .instantiate(
            TransactionId(10),
            BlockContext::default(),
            Address::from("verifier"),
            code_id,
            None,
            "pool-hackatom-a".to_owned(),
            vec![Coin::new(100_u128, "utest")],
            to_json_binary(&json!({
                "verifier": "verifier",
                "beneficiary": "beneficiary-a"
            }))
            .unwrap(),
        )
        .unwrap()
        .contract;
    let contract_b = engine
        .instantiate(
            TransactionId(11),
            BlockContext::default(),
            Address::from("verifier"),
            code_id,
            None,
            "pool-hackatom-b".to_owned(),
            vec![Coin::new(100_u128, "utest")],
            to_json_binary(&json!({
                "verifier": "verifier",
                "beneficiary": "beneficiary-b"
            }))
            .unwrap(),
        )
        .unwrap()
        .contract;

    let transactions = vec![
        CanonicalTransaction::new(
            BlockContext {
                transaction_index: Some(0),
                ..BlockContext::default()
            },
            ExecutionRequest::Execute {
                transaction_id: TransactionId(12),
                sender: Address::from("verifier"),
                contract: contract_a,
                funds: Vec::new(),
                msg: Binary::from(br#"{"release":{}}"#.as_slice()),
            },
        ),
        CanonicalTransaction::new(
            BlockContext {
                transaction_index: Some(1),
                ..BlockContext::default()
            },
            ExecutionRequest::Execute {
                transaction_id: TransactionId(13),
                sender: Address::from("verifier"),
                contract: contract_b,
                funds: Vec::new(),
                msg: Binary::from(br#"{"release":{}}"#.as_slice()),
            },
        ),
    ];

    let prepared = engine
        .preexecute_dependency_plan(
            ParallelExecutionConfig { workers: 3 },
            transactions.clone(),
            vec![SpeculativeWave::new(vec![
                TransactionId(12),
                TransactionId(13),
            ])],
            Vec::new(),
        )
        .unwrap();

    let dependency = &prepared.metrics.dependency_diagnostics;
    let pool = dependency.wasm_instance_pool;
    assert!(pool.enabled);
    assert_eq!(pool.preparer_threads, 1);
    assert_eq!(pool.execution_threads, 2);
    assert_eq!(pool.predicted_codes, 1);
    assert_eq!(pool.pool_requests, 2);
    assert_eq!(pool.consumed_instances, 2);
    assert!(pool.prepared_instances >= 2);
    assert_eq!(dependency.contract.wasm_instance_acquires, 0);
    assert_eq!(dependency.contract.wasm_entrypoint_calls, 2);
    assert_eq!(dependency.contract.wasm_instance_recycles, 2);
    assert!(dependency.contract.wasm_cache_pinned_hits >= 2);

    let outcome = engine
        .reconcile_prepared_block(transactions, prepared)
        .unwrap();
    assert_eq!(outcome.speculative.reused_results, 2);
    assert_eq!(outcome.speculative.replayed_transactions, 0);
}

#[test]
fn adaptive_fresh_instance_pool_keeps_full_execution_thread_budget() {
    let engine = CosmWasmEngine::new(EngineConfig {
        wasm_instance_pool: WasmInstancePoolConfig {
            preparer_threads: 1,
            target_per_code: 4,
            initial_per_code: 1,
            adaptive_preparation: true,
            low_watermark_per_code: 2,
        },
        ..EngineConfig::default()
    });
    engine
        .set_balance("verifier", &[Coin::new(500_u128, "utest")])
        .unwrap();
    let compact: String = HACKATOM_BASE64.split_whitespace().collect();
    let wasm = STANDARD.decode(compact).unwrap();
    let code_id = engine.upload_wasm(wasm).unwrap();

    let contract_a = engine
        .instantiate(
            TransactionId(40),
            BlockContext::default(),
            Address::from("verifier"),
            code_id,
            None,
            "adaptive-pool-a".to_owned(),
            vec![Coin::new(100_u128, "utest")],
            to_json_binary(&json!({
                "verifier": "verifier",
                "beneficiary": "adaptive-beneficiary-a"
            }))
            .unwrap(),
        )
        .unwrap()
        .contract;
    let contract_b = engine
        .instantiate(
            TransactionId(41),
            BlockContext::default(),
            Address::from("verifier"),
            code_id,
            None,
            "adaptive-pool-b".to_owned(),
            vec![Coin::new(100_u128, "utest")],
            to_json_binary(&json!({
                "verifier": "verifier",
                "beneficiary": "adaptive-beneficiary-b"
            }))
            .unwrap(),
        )
        .unwrap()
        .contract;

    let transactions = vec![
        CanonicalTransaction::new(
            BlockContext {
                transaction_index: Some(0),
                ..BlockContext::default()
            },
            ExecutionRequest::Execute {
                transaction_id: TransactionId(42),
                sender: Address::from("verifier"),
                contract: contract_a,
                funds: Vec::new(),
                msg: Binary::from(br#"{"release":{}}"#.as_slice()),
            },
        ),
        CanonicalTransaction::new(
            BlockContext {
                transaction_index: Some(1),
                ..BlockContext::default()
            },
            ExecutionRequest::Execute {
                transaction_id: TransactionId(43),
                sender: Address::from("verifier"),
                contract: contract_b,
                funds: Vec::new(),
                msg: Binary::from(br#"{"release":{}}"#.as_slice()),
            },
        ),
    ];

    let prepared = engine
        .preexecute_dependency_plan(
            ParallelExecutionConfig { workers: 2 },
            transactions.clone(),
            vec![SpeculativeWave::new(vec![
                TransactionId(42),
                TransactionId(43),
            ])],
            Vec::new(),
        )
        .unwrap();

    let dependency = &prepared.metrics.dependency_diagnostics;
    let pool = dependency.wasm_instance_pool;
    assert!(pool.enabled);
    assert!(pool.adaptive_preparation);
    assert_eq!(pool.preparer_threads, 0);
    assert_eq!(pool.max_preparer_threads, 1);
    assert_eq!(pool.execution_threads, 2);
    assert_eq!(pool.pool_requests, 2);
    assert_eq!(pool.consumed_instances, 2);
    assert!(pool.adaptive_prepare_requests > 0);
    assert_eq!(pool.max_concurrent_adaptive_preparers, 1);
    assert_eq!(dependency.contract.wasm_instance_acquires, 0);

    let outcome = engine
        .reconcile_prepared_block(transactions, prepared)
        .unwrap();
    assert_eq!(outcome.speculative.reused_results, 2);
    assert_eq!(outcome.speculative.replayed_transactions, 0);
}


#[test]
fn fresh_instance_pool_never_steals_the_only_execution_worker() {
    let engine = CosmWasmEngine::new(EngineConfig {
        wasm_instance_pool: WasmInstancePoolConfig {
            preparer_threads: 4,
            target_per_code: 4,
            initial_per_code: 1,
            ..WasmInstancePoolConfig::default()
        },
        ..EngineConfig::default()
    });
    engine
        .set_balance("verifier", &[Coin::new(250_u128, "utest")])
        .unwrap();
    let compact: String = HACKATOM_BASE64.split_whitespace().collect();
    let wasm = STANDARD.decode(compact).unwrap();
    let code_id = engine.upload_wasm(wasm).unwrap();
    let contract = engine
        .instantiate(
            TransactionId(30),
            BlockContext::default(),
            Address::from("verifier"),
            code_id,
            None,
            "single-worker-pool-guard".to_owned(),
            vec![Coin::new(100_u128, "utest")],
            to_json_binary(&json!({
                "verifier": "verifier",
                "beneficiary": "beneficiary"
            }))
            .unwrap(),
        )
        .unwrap()
        .contract;
    let transaction = CanonicalTransaction::new(
        BlockContext {
            transaction_index: Some(0),
            ..BlockContext::default()
        },
        ExecutionRequest::Execute {
            transaction_id: TransactionId(31),
            sender: Address::from("verifier"),
            contract,
            funds: Vec::new(),
            msg: Binary::from(br#"{"release":{}}"#.as_slice()),
        },
    );

    let prepared = engine
        .preexecute_dependency_plan(
            ParallelExecutionConfig { workers: 1 },
            vec![transaction.clone()],
            vec![SpeculativeWave::new(vec![TransactionId(31)])],
            Vec::new(),
        )
        .unwrap();

    let dependency = &prepared.metrics.dependency_diagnostics;
    assert!(!dependency.wasm_instance_pool.enabled);
    assert_eq!(dependency.contract.wasm_instance_acquires, 1);
    assert_eq!(dependency.contract.wasm_entrypoint_calls, 1);

    let outcome = engine
        .reconcile_prepared_block(vec![transaction], prepared)
        .unwrap();
    assert_eq!(outcome.speculative.reused_results, 1);
    assert_eq!(outcome.speculative.replayed_transactions, 0);
}
