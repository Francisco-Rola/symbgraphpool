use std::fs;
use std::path::PathBuf;
use std::sync::Arc;

use cosmwasm_std::{
    to_json_binary, Addr, ContractResult, Empty, MessageInfo, Response, Uint128,
};
use cosmwasm_vm::{Backend, Instance, InstanceOptions};
use parking_lot::{Mutex, RwLock};
use serde::{Deserialize, Serialize};

use super::*;

const LEAK_BYTES_PER_CALL: u32 = 2 * 1024 * 1024;
const PROBE_ACCOUNT: &str = "probe-account";
const PROBE_DENOM: &str = "utest";
const RETAINED_SENTINEL: u8 = 0xA5;

type ProbeInstance = Instance<EngineApi, EngineStorage, EngineQuerier>;

#[derive(Serialize)]
#[serde(rename_all = "snake_case")]
enum ProbeExecuteMsg {
    Probe { leak_bytes: u32 },
}

#[derive(Debug, Deserialize, PartialEq, Eq)]
struct ProbeObservation {
    counter_before: u32,
    sentinel_before: u8,
    backend_marker: String,
    backend_balance: Uint128,
}

fn probe_wasm_path() -> PathBuf {
    std::env::var_os("ACG_RETAINED_INSTANCE_PROBE_WASM")
        .map(PathBuf::from)
        .unwrap_or_else(|| {
            PathBuf::from(env!("CARGO_MANIFEST_DIR")).join(
                "../../../benchmarks/target/wasm32-unknown-unknown/release/acg_retained_instance_probe.wasm",
            )
        })
}

fn load_probe_wasm() -> Vec<u8> {
    let path = probe_wasm_path();
    fs::read(&path).unwrap_or_else(|error| {
        panic!(
            "failed to read retained-instance probe Wasm at {}: {error}. \
             Build it first with `cargo build --manifest-path benchmarks/Cargo.toml \
             -p acg-retained-instance-probe --release --target wasm32-unknown-unknown`, \
             or set ACG_RETAINED_INSTANCE_PROBE_WASM",
            path.display()
        )
    })
}

fn probe_code(engine: &CosmWasmEngine) -> (CodeId, cosmwasm_std::Checksum, CodeChecksum) {
    let code_id = engine.upload_wasm(load_probe_wasm()).unwrap();
    let record = engine.core.code(code_id).unwrap();
    let checksum = match record.artifact {
        CodeArtifact::Wasm(checksum) => checksum,
        CodeArtifact::Native(_) => panic!("probe code unexpectedly registered as native"),
    };
    (code_id, checksum, record.metadata.checksum)
}

fn transaction_with_backend_marker(
    code_id: CodeId,
    code_checksum: CodeChecksum,
    contract: &Address,
    transaction_id: TransactionId,
    marker: &str,
    balance: u128,
) -> SharedTx {
    let mut world = WorldState::default();
    world.contracts.insert(
        contract.clone(),
        ContractMetadata {
            address: contract.clone(),
            code_id,
            code_checksum,
            creator: Address::from("probe-creator"),
            admin: None,
            label: "retained-instance-probe".to_owned(),
        },
    );
    world
        .storage
        .entry(contract.clone())
        .or_default()
        .insert(b"marker".to_vec(), marker.as_bytes().to_vec());
    world.balances.insert(
        (Address::from(PROBE_ACCOUNT), PROBE_DENOM.to_owned()),
        Uint128::new(balance),
    );

    Arc::new(Mutex::new(TransactionState::new(
        Arc::new(RwLock::new(world)),
        transaction_id,
    )))
}

fn acquire_probe_instance(
    engine: &CosmWasmEngine,
    checksum: &cosmwasm_std::Checksum,
    contract: &Address,
    tx: SharedTx,
    block: &BlockContext,
) -> ProbeInstance {
    let backend = Backend {
        api: EngineApi,
        storage: EngineStorage::new(contract.clone(), 0, tx.clone()),
        querier: EngineQuerier::new(
            engine.core.clone(),
            tx,
            contract.clone(),
            block.clone(),
            0,
        ),
    };
    engine
        .core
        .wasm_cache
        .get_instance(
            checksum,
            backend,
            InstanceOptions {
                gas_limit: engine.core.config.gas_limit,
            },
        )
        .unwrap()
}

fn acquire_probe_instance_from_shard(
    engine: &CosmWasmEngine,
    shard_index: usize,
    checksum: &cosmwasm_std::Checksum,
    contract: &Address,
    tx: SharedTx,
    block: &BlockContext,
) -> ProbeInstance {
    let backend = Backend {
        api: EngineApi,
        storage: EngineStorage::new(contract.clone(), 0, tx.clone()),
        querier: EngineQuerier::new(
            engine.core.clone(),
            tx,
            contract.clone(),
            block.clone(),
            0,
        ),
    };
    engine.core.wasm_fresh_instance_cache_shards[shard_index]
        .get_instance(
            checksum,
            backend,
            InstanceOptions {
                gas_limit: engine.core.config.gas_limit,
            },
        )
        .unwrap()
}

fn execute_probe(
    instance: &mut ProbeInstance,
    contract: &Address,
    block: &BlockContext,
) -> ProbeObservation {
    let env = make_env(block, contract);
    let info = MessageInfo {
        sender: Addr::unchecked("probe-sender"),
        funds: Vec::new(),
    };
    let msg = to_json_binary(&ProbeExecuteMsg::Probe {
        leak_bytes: LEAK_BYTES_PER_CALL,
    })
    .unwrap();
    let result: ContractResult<Response<Empty>> =
        call_execute(instance, &env, &info, &msg).unwrap();
    let response = result.into_result().unwrap();
    let data = response.data.expect("probe response must contain data");
    serde_json::from_slice(data.as_slice()).unwrap()
}

fn rebind_probe_backend(
    engine: &CosmWasmEngine,
    instance: &mut ProbeInstance,
    contract: &Address,
    tx: SharedTx,
    block: &BlockContext,
) {
    instance
        .with_storage(|storage| {
            storage.rebind(contract.clone(), 0, tx.clone());
            Ok(())
        })
        .unwrap();
    instance
        .with_querier(|querier| {
            querier.rebind(
                engine.core.clone(),
                tx,
                contract.clone(),
                block.clone(),
                0,
            );
            Ok(())
        })
        .unwrap();
}

#[test]
#[ignore = "requires the purpose-built retained-instance probe Wasm artifact"]
fn fresh_instances_reset_vm_local_state_and_use_their_own_backends() {
    let engine = CosmWasmEngine::default();
    let (code_id, checksum, code_checksum) = probe_code(&engine);
    let contract = Address::from("probe-contract");
    let block_a = BlockContext {
        transaction_index: Some(0),
        ..BlockContext::default()
    };
    let block_b = BlockContext {
        transaction_index: Some(1),
        ..BlockContext::default()
    };
    let tx_a = transaction_with_backend_marker(
        code_id,
        code_checksum,
        &contract,
        TransactionId(100),
        "backend-A",
        11,
    );
    let tx_b = transaction_with_backend_marker(
        code_id,
        code_checksum,
        &contract,
        TransactionId(101),
        "backend-B",
        22,
    );

    let mut first = acquire_probe_instance(&engine, &checksum, &contract, tx_a, &block_a);
    let first_initial_gas = first.get_gas_left();
    let first_initial_pages = first.memory_pages();
    let first_observation = execute_probe(&mut first, &contract, &block_a);
    let first_final_gas = first.get_gas_left();
    let first_final_pages = first.memory_pages();
    drop(first.recycle());

    let mut second = acquire_probe_instance(&engine, &checksum, &contract, tx_b, &block_b);
    let second_initial_gas = second.get_gas_left();
    let second_initial_pages = second.memory_pages();
    let second_observation = execute_probe(&mut second, &contract, &block_b);
    let second_final_gas = second.get_gas_left();
    let second_final_pages = second.memory_pages();
    drop(second.recycle());

    assert_eq!(first_observation.counter_before, 0);
    assert_eq!(first_observation.sentinel_before, 0);
    assert_eq!(first_observation.backend_marker, "backend-A");
    assert_eq!(first_observation.backend_balance, Uint128::new(11));
    assert_eq!(second_observation.counter_before, 0);
    assert_eq!(second_observation.sentinel_before, 0);
    assert_eq!(second_observation.backend_marker, "backend-B");
    assert_eq!(second_observation.backend_balance, Uint128::new(22));
    assert_eq!(first_initial_gas, second_initial_gas);
    assert!(first_final_gas < first_initial_gas);
    assert!(second_final_gas < second_initial_gas);

    println!("fresh-instance baseline:");
    println!(
        "  first  counter/sentinel/backend/balance = {}/{:#04x}/{}/{}",
        first_observation.counter_before,
        first_observation.sentinel_before,
        first_observation.backend_marker,
        first_observation.backend_balance
    );
    println!(
        "  second counter/sentinel/backend/balance = {}/{:#04x}/{}/{}",
        second_observation.counter_before,
        second_observation.sentinel_before,
        second_observation.backend_marker,
        second_observation.backend_balance
    );
    println!(
        "  gas initial/final: first {first_initial_gas}/{first_final_gas}, second {second_initial_gas}/{second_final_gas}"
    );
    println!(
        "  memory pages initial/final: first {first_initial_pages}/{first_final_pages}, second {second_initial_pages}/{second_final_pages}"
    );
}

#[test]
#[ignore = "requires the purpose-built retained-instance probe Wasm artifact"]
fn fresh_cache_shard_instances_reset_vm_state_and_backends() {
    let engine = CosmWasmEngine::new(EngineConfig {
        wasm_fresh_instance_cache_shards: 2,
        ..EngineConfig::default()
    });
    let (code_id, checksum, code_checksum) = probe_code(&engine);
    assert_eq!(engine.core.wasm_fresh_instance_cache_shards.len(), 2);

    let contract = Address::from("probe-contract");
    let block_a = BlockContext {
        transaction_index: Some(0),
        ..BlockContext::default()
    };
    let block_b = BlockContext {
        transaction_index: Some(1),
        ..BlockContext::default()
    };
    let tx_a = transaction_with_backend_marker(
        code_id,
        code_checksum,
        &contract,
        TransactionId(300),
        "shard-A",
        31,
    );
    let tx_b = transaction_with_backend_marker(
        code_id,
        code_checksum,
        &contract,
        TransactionId(301),
        "shard-B",
        32,
    );

    // Two sequential calls through the same prewarmed shard must still get different, pristine
    // VM instances. This is the semantic-reset property the prototype is designed to preserve.
    let mut first = acquire_probe_instance_from_shard(
        &engine, 0, &checksum, &contract, tx_a, &block_a,
    );
    let first_initial_gas = first.get_gas_left();
    let first_initial_pages = first.memory_pages();
    let first_observation = execute_probe(&mut first, &contract, &block_a);
    let first_final_gas = first.get_gas_left();
    let first_final_pages = first.memory_pages();
    drop(first.recycle());

    let mut second = acquire_probe_instance_from_shard(
        &engine, 0, &checksum, &contract, tx_b, &block_b,
    );
    let second_initial_gas = second.get_gas_left();
    let second_initial_pages = second.memory_pages();
    let second_observation = execute_probe(&mut second, &contract, &block_b);
    let second_final_gas = second.get_gas_left();
    let second_final_pages = second.memory_pages();
    drop(second.recycle());

    assert_eq!(first_observation.counter_before, 0);
    assert_eq!(first_observation.sentinel_before, 0);
    assert_eq!(second_observation.counter_before, 0);
    assert_eq!(second_observation.sentinel_before, 0);
    assert_eq!(first_observation.backend_marker, "shard-A");
    assert_eq!(second_observation.backend_marker, "shard-B");
    assert_eq!(first_observation.backend_balance, Uint128::new(31));
    assert_eq!(second_observation.backend_balance, Uint128::new(32));
    assert_eq!(first_initial_gas, second_initial_gas);
    assert!(first_final_gas < first_initial_gas);
    assert!(second_final_gas < second_initial_gas);
    assert_eq!(first_initial_pages, second_initial_pages);
    assert!(first_final_pages >= first_initial_pages);
    assert!(second_final_pages >= second_initial_pages);

    println!("fresh-cache-shard semantic reset:");
    println!(
        "  same shard call A/B counter+sentinel = {}/{:#04x} then {}/{:#04x}",
        first_observation.counter_before,
        first_observation.sentinel_before,
        second_observation.counter_before,
        second_observation.sentinel_before
    );
    println!(
        "  initial gas A/B = {first_initial_gas}/{second_initial_gas}; initial pages A/B = {first_initial_pages}/{second_initial_pages}"
    );
}

#[test]
#[ignore = "requires the purpose-built retained-instance probe Wasm artifact"]
fn six_fresh_cache_shards_are_isolated_under_concurrent_instantiation() {
    const SHARDS: usize = 6;
    const CALLS_PER_SHARD: usize = 16;

    let engine = CosmWasmEngine::new(EngineConfig {
        wasm_fresh_instance_cache_shards: SHARDS,
        ..EngineConfig::default()
    });
    let (code_id, checksum, code_checksum) = probe_code(&engine);
    let contract = Address::from("probe-contract");

    std::thread::scope(|scope| {
        for shard_index in 0..SHARDS {
            let engine = engine.clone();
            let contract = contract.clone();
            scope.spawn(move || {
                for call_index in 0..CALLS_PER_SHARD {
                    let ordinal = shard_index * CALLS_PER_SHARD + call_index;
                    let marker = format!("shard-{shard_index}-call-{call_index}");
                    let balance = 1_000_u128 + ordinal as u128;
                    let tx = transaction_with_backend_marker(
                        code_id,
                        code_checksum,
                        &contract,
                        TransactionId(10_000 + ordinal as u64),
                        &marker,
                        balance,
                    );
                    let block = BlockContext {
                        transaction_index: Some(ordinal as u32),
                        ..BlockContext::default()
                    };
                    let mut instance = acquire_probe_instance_from_shard(
                        &engine,
                        shard_index,
                        &checksum,
                        &contract,
                        tx,
                        &block,
                    );
                    let initial_gas = instance.get_gas_left();
                    let initial_pages = instance.memory_pages();
                    let observation = execute_probe(&mut instance, &contract, &block);
                    assert_eq!(observation.counter_before, 0);
                    assert_eq!(observation.sentinel_before, 0);
                    assert_eq!(observation.backend_marker, marker);
                    assert_eq!(observation.backend_balance, Uint128::new(balance));
                    assert!(instance.get_gas_left() < initial_gas);
                    assert!(instance.memory_pages() >= initial_pages);
                    drop(instance.recycle());
                }
            });
        }
    });

    println!(
        "fresh-cache-shard concurrent isolation: {} fresh calls across {} shards all passed",
        SHARDS * CALLS_PER_SHARD,
        SHARDS
    );
}

#[test]
#[ignore = "requires the purpose-built retained-instance probe Wasm artifact"]
fn retained_instance_rebinds_backend_but_does_not_provide_fresh_vm_isolation() {
    let engine = CosmWasmEngine::default();
    let (code_id, checksum, code_checksum) = probe_code(&engine);
    let contract = Address::from("probe-contract");
    let block_a = BlockContext {
        transaction_index: Some(0),
        ..BlockContext::default()
    };
    let block_b = BlockContext {
        transaction_index: Some(1),
        ..BlockContext::default()
    };
    let tx_a = transaction_with_backend_marker(
        code_id,
        code_checksum,
        &contract,
        TransactionId(200),
        "backend-A",
        11,
    );
    let tx_b = transaction_with_backend_marker(
        code_id,
        code_checksum,
        &contract,
        TransactionId(201),
        "backend-B",
        22,
    );

    let mut instance =
        acquire_probe_instance(&engine, &checksum, &contract, tx_a, &block_a);
    let initial_gas = instance.get_gas_left();
    let initial_pages = instance.memory_pages();

    let first = execute_probe(&mut instance, &contract, &block_a);
    let gas_after_first = instance.get_gas_left();
    let pages_after_first = instance.memory_pages();

    rebind_probe_backend(&engine, &mut instance, &contract, tx_b, &block_b);
    let gas_before_second = instance.get_gas_left();
    let pages_before_second = instance.memory_pages();
    let second = execute_probe(&mut instance, &contract, &block_b);
    let gas_after_second = instance.get_gas_left();
    let pages_after_second = instance.memory_pages();

    assert_eq!(first.counter_before, 0);
    assert_eq!(first.sentinel_before, 0);
    assert_eq!(first.backend_marker, "backend-A");
    assert_eq!(first.backend_balance, Uint128::new(11));

    // Backend rebinding is feasible: the same retained VM reaches transaction B's storage and
    // querier after the host-side backend handles are rebound.
    assert_eq!(second.backend_marker, "backend-B");
    assert_eq!(second.backend_balance, Uint128::new(22));

    // Naive whole-Instance reuse is NOT fresh-transaction equivalent. The contract's deliberately
    // VM-local linear-memory state survives the first call and is visible to the second call.
    assert_eq!(second.counter_before, 1);
    assert_eq!(second.sentinel_before, RETAINED_SENTINEL);

    // Rebinding itself must not consume VM gas. Whether `call_execute` resets the gas meter for the
    // second call is intentionally observed rather than assumed; the printed values tell us whether
    // a production retained-instance design would also need an explicit per-transaction gas reset.
    assert_eq!(gas_before_second, gas_after_first);
    assert!(gas_after_first < initial_gas);

    // Wasm memory cannot shrink during one Instance lifetime. Deliberate leaked allocations make
    // this visible and guard against accidentally treating retained memory as a fresh VM.
    assert_eq!(pages_before_second, pages_after_first);
    assert!(pages_after_first >= initial_pages);
    assert!(pages_after_second >= pages_before_second);

    println!("retained-instance isolation experiment:");
    println!(
        "  call A counter/sentinel/backend/balance = {}/{:#04x}/{}/{}",
        first.counter_before, first.sentinel_before, first.backend_marker, first.backend_balance
    );
    println!(
        "  call B counter/sentinel/backend/balance = {}/{:#04x}/{}/{}",
        second.counter_before, second.sentinel_before, second.backend_marker, second.backend_balance
    );
    println!(
        "  gas initial/after-A/before-B/after-B = {initial_gas}/{gas_after_first}/{gas_before_second}/{gas_after_second}"
    );
    println!(
        "  memory pages initial/after-A/before-B/after-B = {initial_pages}/{pages_after_first}/{pages_before_second}/{pages_after_second}"
    );
    println!(
        "  verdict: backend rebinding works, but raw retained Instance reuse leaks VM-local memory and shares one gas budget"
    );

    drop(instance.recycle());
}

#[test]
#[ignore = "requires the purpose-built retained-instance probe Wasm artifact"]
fn fresh_instance_pool_rebinds_backends_without_leaking_vm_local_state() {
    let engine = CosmWasmEngine::new(EngineConfig {
        wasm_instance_pool: WasmInstancePoolConfig {
            preparer_threads: 1,
            target_per_code: 2,
            initial_per_code: 2,
            ..WasmInstancePoolConfig::default()
        },
        ..EngineConfig::default()
    });
    let code_id = engine.upload_wasm(load_probe_wasm()).unwrap();
    let contract = engine
        .instantiate(
            TransactionId(200),
            BlockContext::default(),
            Address::from("probe-creator"),
            code_id,
            None,
            "fresh-pool-probe".to_owned(),
            Vec::new(),
            to_json_binary(&Empty {}).unwrap(),
        )
        .unwrap()
        .contract;

    let make_transaction = |index: usize, transaction_id: u64| {
        CanonicalTransaction::new(
            BlockContext {
                transaction_index: Some(index as u32),
                ..BlockContext::default()
            },
            ExecutionRequest::Execute {
                transaction_id: TransactionId(transaction_id),
                sender: Address::from("probe-sender"),
                contract: contract.clone(),
                funds: Vec::new(),
                msg: to_json_binary(&ProbeExecuteMsg::Probe {
                    leak_bytes: LEAK_BYTES_PER_CALL,
                })
                .unwrap(),
            },
        )
    };
    let transactions = vec![make_transaction(0, 201), make_transaction(1, 202)];
    let prepared = engine
        .preexecute_dependency_plan(
            ParallelExecutionConfig { workers: 2 },
            transactions.clone(),
            vec![SpeculativeWave::new(vec![
                TransactionId(201),
                TransactionId(202),
            ])],
            Vec::new(),
        )
        .unwrap();

    let observations = prepared
        .receipts
        .iter()
        .map(|receipt| match &receipt.status {
            SpeculativeExecutionStatus::Succeeded(outcome) => {
                let data = outcome.data.as_ref().expect("probe response data");
                serde_json::from_slice::<ProbeObservation>(data.as_slice()).unwrap()
            }
            SpeculativeExecutionStatus::Failed(error) => {
                panic!("fresh-pool probe failed: {error}")
            }
        })
        .collect::<Vec<_>>();
    assert_eq!(observations.len(), 2);
    for observation in &observations {
        assert_eq!(observation.counter_before, 0);
        assert_eq!(observation.sentinel_before, 0);
    }

    let pool = prepared.metrics.dependency_diagnostics.wasm_instance_pool;
    assert!(pool.enabled);
    assert_eq!(pool.preparer_threads, 1);
    assert_eq!(pool.execution_threads, 1);
    assert_eq!(pool.predicted_codes, 1);
    assert_eq!(pool.pool_requests, 2);
    assert_eq!(pool.consumed_instances, 2);
    assert!(pool.prepared_instances >= 2);

    let outcome = engine.reconcile_prepared_block(transactions, prepared).unwrap();
    assert_eq!(outcome.speculative.reused_results, 2);
    assert_eq!(outcome.speculative.replayed_transactions, 0);

    println!("fresh-instance pool isolation experiment:");
    println!(
        "  observations counter/sentinel = {}/{:#04x}, {}/{:#04x}",
        observations[0].counter_before,
        observations[0].sentinel_before,
        observations[1].counter_before,
        observations[1].sentinel_before
    );
    println!(
        "  pool prepared/consumed/immediate/waited/unused = {}/{}/{}/{}/{}",
        pool.prepared_instances,
        pool.consumed_instances,
        pool.immediate_hits,
        pool.waited_requests,
        pool.unused_instances
    );
}
