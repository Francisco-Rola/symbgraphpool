# Fresh VM reset prototype: semantic reset by reconstruction

## Why the prototype does not reset a dirty `Instance` in place

The unsafe retained-instance experiment proved that rebinding `EngineStorage` and `EngineQuerier` is
not enough: contract linear memory and the VM gas budget survive when the same mutable VM instance
is reused. A generally correct in-place reset would also need to restore every piece of mutable
WebAssembly/runtime state, including linear memory contents and size, mutable globals, tables,
metering state, host environment state, and any other store-local runtime data.

The public `cosmwasm_vm::Instance` surface used by this engine does not expose a complete mechanism
to restore all of those categories to their post-instantiation values. In particular, an ACG-only
"copy the initial memory bytes back" implementation would not be a correctness proof: memory may
have grown and non-memory mutable WebAssembly state may have changed.

For that reason this prototype implements **semantic reset by reconstruction** rather than dirty
instance reset.

## Design

`EngineConfig::wasm_fresh_instance_cache_shards = N` creates `N` independent `cosmwasm_vm::Cache`
objects over the canonical cache's trusted filesystem artifact directory.

Each shard owns its own:

- Wasmer engine;
- in-memory compiled-module cache;
- CosmWasm instantiation lock.

The canonical cache remains responsible for uploading/storing Wasm. After a successful upload, the
same checksum is pinned into every shard before measured execution. READY-DAG worker `i` is assigned
shard `i % N` for the lifetime of that worker. Nested contract calls on that worker inherit the same
shard.

Every contract invocation still calls the normal public `Cache::get_instance` API. Therefore every
transaction gets a newly constructed mutable Wasm instance. No dirty linear memory, globals, tables,
gas state, backend handles, or iterators are intentionally carried from one transaction to another.
The reusable object is the compiled module template in the worker's cache shard, not an executed
`Instance`.

The mode is mutually exclusive with the block-local fresh-instance pool and with benchmark-only
unsafe dirty-instance reuse so measurements are unambiguous.

## Correctness gates

`retained_instance_tests` contains the following relevant controls:

1. canonical fresh instances: positive baseline;
2. unsafe retained instance: negative control that must continue to expose VM-local leakage;
3. same-shard sequential fresh instances: counter/sentinel, gas, initial memory size and backend
   identity must reset;
4. six-shard concurrent stress: all calls must observe pristine VM-local state and their own backend;
5. existing fresh-instance-pool isolation test: independent positive baseline.

The MiniWarehouse diagnostic additionally requires the sharded execution's final world state to
match the independently executed fresh serial world.

These tests validate the VM state categories observable through the current test contract and host
API. They do not constitute a formal proof of all internals of Wasmer/CosmWasm, so the mode remains
experimental until it also survives long-running stress, sanitizers where applicable, and upstream
compatibility review.

## Evaluation

Two scripts compare three modes:

- `fresh`: one canonical CosmWasm cache shared by all workers;
- `sharded`: correct fresh instances from prewarmed per-worker cache shards;
- `retained-upper-bound`: deliberately invalid dirty VM reuse.

Interpretation:

- **sharded ~= retained**: most lifecycle loss came from sharing the canonical cache/engine
  instantiation path; per-worker fresh templates are promising;
- **fresh < sharded < retained**: both shared-instantiation contention and fresh mutable-instance
  construction matter;
- **sharded ~= fresh**: creating fresh Store/Instance state dominates. The next research step would
  need to move below the public CosmWasm `Instance` API and investigate a correct snapshot/COW or
  instance-preinitialization mechanism that restores memory, globals, tables, gas and host state.

The sharded design intentionally trades additional compiled-module memory and upload-time warmup for
parallel fresh instantiation. Those costs must be measured before considering production use.
