use std::cell::RefCell;
use std::collections::BTreeMap;
use std::sync::Arc;
use std::time::{Duration, Instant};

use cosmwasm_std::Checksum;
use cosmwasm_vm::Instance;
use parking_lot::{Condvar, Mutex};

use crate::api::EngineApi;
use crate::engine::EngineCore;
use crate::error::{EngineError, EngineResult};
use crate::parallel::ExecutionHotPathDiagnostics;
use crate::querier::EngineQuerier;
use crate::state::SharedTx;
use crate::storage::EngineStorage;
use crate::types::{Address, BlockContext, CodeChecksum};

pub(crate) type EngineWasmInstance = Instance<EngineApi, EngineStorage, EngineQuerier>;

/// Returns whether a validated Wasm module is safe to instantiate before its real transaction
/// backend is known.
///
/// A WebAssembly start section runs during instantiation. If it were allowed into the fresh pool,
/// its host calls and VM-local mutations would run against the placeholder backend rather than the
/// transaction backend. Normal CosmWasm Rust contracts do not need a start section, so conservatively
/// bypass pooling whenever section id 8 is present or the byte stream cannot be walked safely.
pub(crate) fn wasm_allows_fresh_instance_preparation(wasm: &[u8]) -> bool {
    const WASM_HEADER: &[u8; 8] = b"\0asm\x01\0\0\0";
    if wasm.len() < WASM_HEADER.len() || &wasm[..WASM_HEADER.len()] != WASM_HEADER {
        return false;
    }

    let mut cursor = WASM_HEADER.len();
    while cursor < wasm.len() {
        let section_id = wasm[cursor];
        cursor += 1;
        let Some((section_len, leb_bytes)) = read_var_u32(&wasm[cursor..]) else {
            return false;
        };
        cursor = match cursor.checked_add(leb_bytes) {
            Some(cursor) => cursor,
            None => return false,
        };
        let section_len = section_len as usize;
        let end = match cursor.checked_add(section_len) {
            Some(end) if end <= wasm.len() => end,
            _ => return false,
        };
        if section_id == 8 {
            return false;
        }
        cursor = end;
    }
    true
}

fn read_var_u32(bytes: &[u8]) -> Option<(u32, usize)> {
    let mut value = 0_u32;
    for (index, byte) in bytes.iter().copied().take(5).enumerate() {
        let shift = (index * 7) as u32;
        let payload = u32::from(byte & 0x7f);
        if index == 4 && payload > 0x0f {
            return None;
        }
        value |= payload << shift;
        if byte & 0x80 == 0 {
            return Some((value, index + 1));
        }
    }
    None
}

/// Configuration for the block-local fresh Wasm-instance preparation pool.
///
/// The pool is intentionally disabled by default. Fixed mode reserves `preparer_threads` from the
/// speculative worker budget. Adaptive mode borrows preparer roles from execution workers instead,
/// so the total number of live worker/preparer threads never exceeds `ParallelExecutionConfig::workers`.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct WasmInstancePoolConfig {
    /// Maximum concurrent preparer slots. Fixed mode reserves these threads from the speculative
    /// worker budget; adaptive mode temporarily borrows up to this many execution workers.
    pub preparer_threads: usize,
    /// Desired number of pristine one-use instances kept ready for each observed code checksum.
    pub target_per_code: usize,
    /// Number of instances per predicted checksum that must be prepared before READY-DAG workers
    /// are released. Keep this small; it is a cold-start hedge, not a second cache.
    pub initial_per_code: usize,
    /// When true, preparer slots are not permanently removed from the execution worker budget.
    /// Instead, execution workers temporarily prepare fresh instances while a code reserve is below
    /// its low watermark, and return to transaction execution after the high watermark is restored.
    pub adaptive_preparation: bool,
    /// Low watermark that activates adaptive refill. A zero value falls back to `initial_per_code`.
    pub low_watermark_per_code: usize,
}

impl WasmInstancePoolConfig {
    pub fn enabled(&self) -> bool {
        self.preparer_threads > 0 && self.target_per_code > 0
    }

    pub fn low_watermark(&self) -> usize {
        let requested = if self.low_watermark_per_code == 0 {
            self.initial_per_code.max(1)
        } else {
            self.low_watermark_per_code
        };
        requested.min(self.target_per_code)
    }
}

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct WasmInstancePoolMetrics {
    pub enabled: bool,
    /// Permanently reserved preparer threads. This is zero in adaptive mode.
    pub preparer_threads: usize,
    /// Maximum concurrent preparer roles allowed by configuration.
    pub max_preparer_threads: usize,
    pub execution_threads: usize,
    pub adaptive_preparation: bool,
    pub low_watermark_per_code: usize,
    pub target_per_code: usize,
    pub predicted_codes: usize,
    pub initial_fill_wall: Duration,
    pub aggregate_prepare_time: Duration,
    pub aggregate_adaptive_prepare_time: Duration,
    pub aggregate_wait_time: Duration,
    pub aggregate_rebind_time: Duration,
    pub prepared_instances: u64,
    pub demand_prepare_requests: u64,
    pub background_prepare_requests: u64,
    pub adaptive_prepare_requests: u64,
    pub max_concurrent_adaptive_preparers: usize,
    pub max_available_per_code: usize,
    pub max_waiters_per_code: usize,
    pub pool_requests: u64,
    pub immediate_hits: u64,
    pub waited_requests: u64,
    pub consumed_instances: u64,
    pub unused_instances: u64,
}

impl WasmInstancePoolMetrics {
    pub fn merge(&mut self, other: &Self) {
        self.enabled |= other.enabled;
        self.preparer_threads = self.preparer_threads.max(other.preparer_threads);
        self.max_preparer_threads = self.max_preparer_threads.max(other.max_preparer_threads);
        self.execution_threads = self.execution_threads.max(other.execution_threads);
        self.adaptive_preparation |= other.adaptive_preparation;
        self.low_watermark_per_code = self.low_watermark_per_code.max(other.low_watermark_per_code);
        self.target_per_code = self.target_per_code.max(other.target_per_code);
        self.predicted_codes = self.predicted_codes.max(other.predicted_codes);
        self.initial_fill_wall += other.initial_fill_wall;
        self.aggregate_prepare_time += other.aggregate_prepare_time;
        self.aggregate_adaptive_prepare_time += other.aggregate_adaptive_prepare_time;
        self.aggregate_wait_time += other.aggregate_wait_time;
        self.aggregate_rebind_time += other.aggregate_rebind_time;
        self.prepared_instances += other.prepared_instances;
        self.demand_prepare_requests += other.demand_prepare_requests;
        self.background_prepare_requests += other.background_prepare_requests;
        self.adaptive_prepare_requests += other.adaptive_prepare_requests;
        self.max_concurrent_adaptive_preparers = self
            .max_concurrent_adaptive_preparers
            .max(other.max_concurrent_adaptive_preparers);
        self.max_available_per_code = self.max_available_per_code.max(other.max_available_per_code);
        self.max_waiters_per_code = self.max_waiters_per_code.max(other.max_waiters_per_code);
        self.pool_requests += other.pool_requests;
        self.immediate_hits += other.immediate_hits;
        self.waited_requests += other.waited_requests;
        self.consumed_instances += other.consumed_instances;
        self.unused_instances += other.unused_instances;
    }
}

struct PoolEntry {
    checksum: Checksum,
    available: Vec<EngineWasmInstance>,
    creating: usize,
    waiters: usize,
    predicted: bool,
}

struct PoolState {
    entries: BTreeMap<CodeChecksum, PoolEntry>,
    active_execution_workers: usize,
    adaptive_preparers: usize,
    adaptive_refill_active: bool,
    failure: Option<String>,
    metrics: WasmInstancePoolMetrics,
}

pub(crate) struct FreshWasmInstancePool {
    core: Arc<EngineCore>,
    config: WasmInstancePoolConfig,
    state: Mutex<PoolState>,
    changed: Condvar,
}

impl FreshWasmInstancePool {
    pub(crate) fn new(
        core: Arc<EngineCore>,
        config: WasmInstancePoolConfig,
        reserved_preparer_threads: usize,
        execution_threads: usize,
        predicted: Vec<(CodeChecksum, Checksum)>,
    ) -> Arc<Self> {
        let mut entries = BTreeMap::new();
        for (key, checksum) in predicted {
            entries.entry(key).or_insert(PoolEntry {
                checksum,
                available: Vec::new(),
                creating: 0,
                waiters: 0,
                predicted: true,
            });
        }
        let predicted_codes = entries.len();
        Arc::new(Self {
            core,
            config: config.clone(),
            state: Mutex::new(PoolState {
                entries,
                active_execution_workers: execution_threads,
                adaptive_preparers: 0,
                adaptive_refill_active: false,
                failure: None,
                metrics: WasmInstancePoolMetrics {
                    enabled: true,
                    preparer_threads: reserved_preparer_threads,
                    max_preparer_threads: config.preparer_threads,
                    execution_threads,
                    adaptive_preparation: config.adaptive_preparation,
                    low_watermark_per_code: config.low_watermark(),
                    target_per_code: config.target_per_code,
                    predicted_codes,
                    ..WasmInstancePoolMetrics::default()
                },
            }),
            changed: Condvar::new(),
        })
    }

    pub(crate) fn preparer_loop(self: Arc<Self>) {
        loop {
            let request = {
                let mut state = self.state.lock();
                loop {
                    if state.failure.is_some() || state.active_execution_workers == 0 {
                        return;
                    }
                    if let Some((key, checksum)) = self.next_prepare_request(&mut state) {
                        break (key, checksum);
                    }
                    self.changed.wait(&mut state);
                }
            };

            if self.prepare_claimed(request, false).is_err() {
                return;
            }
        }
    }

    /// Adaptive mode performs the small cold-start fill synchronously before execution workers are
    /// spawned. This keeps the total live thread count within the configured worker/core budget.
    pub(crate) fn prepare_initial_fill_inline(&self) -> EngineResult<()> {
        if self.config.initial_per_code == 0 {
            return Ok(());
        }
        let target = self
            .config
            .initial_per_code
            .min(self.config.target_per_code);
        let started = Instant::now();
        loop {
            let request = {
                let mut state = self.state.lock();
                if let Some(failure) = state.failure.clone() {
                    return Err(EngineError::Internal(failure));
                }
                let mut request = None;
                for (key, entry) in state.entries.iter_mut() {
                    if entry.predicted && entry.available.len() + entry.creating < target {
                        entry.creating += 1;
                        request = Some((*key, entry.checksum));
                        break;
                    }
                }
                if request.is_some() {
                    state.metrics.background_prepare_requests += 1;
                }
                request
            };

            let Some(request) = request else {
                self.state.lock().metrics.initial_fill_wall += started.elapsed();
                return Ok(());
            };
            self.prepare_claimed(request, false)?;
        }
    }

    pub(crate) fn adaptive_preparation_enabled(&self) -> bool {
        self.config.adaptive_preparation
    }

    /// Let one execution worker temporarily act as a preparer. At most `preparer_threads` workers
    /// may do this concurrently. Once the low watermark is crossed, refill continues toward the
    /// high watermark (`target_per_code`) so refill work is naturally bursty rather than permanent.
    pub(crate) fn maybe_prepare_adaptive(&self) -> EngineResult<bool> {
        if !self.config.adaptive_preparation {
            return Ok(false);
        }

        let request = {
            let mut state = self.state.lock();
            if let Some(failure) = state.failure.clone() {
                return Err(EngineError::Internal(failure));
            }
            if state.active_execution_workers == 0
                || state.adaptive_preparers >= self.config.preparer_threads
            {
                return Ok(false);
            }
            let Some(request) = self.next_adaptive_prepare_request(&mut state) else {
                return Ok(false);
            };
            state.adaptive_preparers += 1;
            let active_adaptive_preparers = state.adaptive_preparers;
            state.metrics.adaptive_prepare_requests += 1;
            state.metrics.max_concurrent_adaptive_preparers = state
                .metrics
                .max_concurrent_adaptive_preparers
                .max(active_adaptive_preparers);
            request
        };

        self.prepare_claimed(request, true)?;
        Ok(true)
    }

    fn prepare_claimed(
        &self,
        request: (CodeChecksum, Checksum),
        adaptive: bool,
    ) -> EngineResult<()> {
        let started = Instant::now();
        let prepared = self.core.prepare_fresh_wasm_instance(&request.1);
        let elapsed = started.elapsed();

        let mut state = self.state.lock();
        state.metrics.aggregate_prepare_time += elapsed;
        if adaptive {
            state.metrics.aggregate_adaptive_prepare_time += elapsed;
            state.adaptive_preparers = state.adaptive_preparers.saturating_sub(1);
        }
        match prepared {
            Ok(instance) => {
                let Some(entry) = state.entries.get_mut(&request.0) else {
                    let message = "fresh Wasm pool lost a registered checksum".to_owned();
                    state.failure = Some(message.clone());
                    self.changed.notify_all();
                    return Err(EngineError::Internal(message));
                };
                entry.creating = entry.creating.saturating_sub(1);
                entry.available.push(instance);
                let available = entry.available.len();
                state.metrics.prepared_instances += 1;
                state.metrics.max_available_per_code =
                    state.metrics.max_available_per_code.max(available);
            }
            Err(error) => {
                if let Some(entry) = state.entries.get_mut(&request.0) {
                    entry.creating = entry.creating.saturating_sub(1);
                }
                let message = format!(
                    "failed to prepare fresh Wasm instance for {}: {error}",
                    request.0
                );
                state.failure = Some(message.clone());
                self.changed.notify_all();
                return Err(EngineError::Internal(message));
            }
        }
        self.changed.notify_all();
        Ok(())
    }

    pub(crate) fn wait_for_initial_fill(&self) -> EngineResult<()> {
        if self.config.initial_per_code == 0 {
            return Ok(());
        }
        let target = self
            .config
            .initial_per_code
            .min(self.config.target_per_code);
        let started = Instant::now();
        let mut state = self.state.lock();
        loop {
            if let Some(failure) = &state.failure {
                return Err(EngineError::Internal(failure.clone()));
            }
            let ready = state
                .entries
                .values()
                .filter(|entry| entry.predicted)
                .all(|entry| entry.available.len() >= target);
            if ready {
                state.metrics.initial_fill_wall += started.elapsed();
                return Ok(());
            }
            self.changed.notify_all();
            self.changed.wait(&mut state);
        }
    }

    pub(crate) fn acquire_rebound(
        &self,
        checksum: &Checksum,
        tx: SharedTx,
        contract: Address,
        block: BlockContext,
        depth: u32,
        diagnostics: &Option<Arc<ExecutionHotPathDiagnostics>>,
    ) -> EngineResult<EngineWasmInstance> {
        let key = code_checksum(checksum);
        let wait_started = Instant::now();
        let mut waited = false;
        let mut state = self.state.lock();
        state.metrics.pool_requests += 1;
        state.entries.entry(key).or_insert_with(|| PoolEntry {
            checksum: *checksum,
            available: Vec::new(),
            creating: 0,
            waiters: 0,
            predicted: false,
        });

        let mut instance = loop {
            if let Some(failure) = state.failure.clone() {
                if waited {
                    if let Some(entry) = state.entries.get_mut(&key) {
                        entry.waiters = entry.waiters.saturating_sub(1);
                    }
                }
                return Err(EngineError::Internal(failure));
            }
            let mut new_waiter_count = None;
            let available = {
                let entry = state
                    .entries
                    .get_mut(&key)
                    .expect("fresh Wasm pool entry was just registered");
                let instance = entry.available.pop();
                if instance.is_some() && waited {
                    entry.waiters = entry.waiters.saturating_sub(1);
                } else if instance.is_none() && !waited {
                    entry.waiters += 1;
                    new_waiter_count = Some(entry.waiters);
                    waited = true;
                }
                instance
            };
            if let Some(waiters) = new_waiter_count {
                state.metrics.max_waiters_per_code =
                    state.metrics.max_waiters_per_code.max(waiters);
            }

            // In adaptive mode there are no permanently dedicated preparer threads. If every
            // execution worker is already inside a transaction and the pool runs dry (for example
            // because of a nested contract call), one blocked worker is allowed to produce the
            // missing instance itself. This is a demand fallback, not background refill, and avoids
            // a deadlock where all workers wait for a preparer role that cannot be scheduled.
            let adaptive_demand_request = if available.is_none()
                && self.config.adaptive_preparation
                && state.adaptive_preparers < self.config.preparer_threads
            {
                let checksum = {
                    let entry = state
                        .entries
                        .get_mut(&key)
                        .expect("fresh Wasm pool entry was just registered");
                    if entry.available.len() + entry.creating < entry.waiters {
                        entry.creating += 1;
                        Some(entry.checksum)
                    } else {
                        None
                    }
                };
                checksum.map(|checksum| {
                    state.adaptive_preparers += 1;
                    let active_adaptive_preparers = state.adaptive_preparers;
                    state.metrics.demand_prepare_requests += 1;
                    state.metrics.adaptive_prepare_requests += 1;
                    state.metrics.max_concurrent_adaptive_preparers = state
                        .metrics
                        .max_concurrent_adaptive_preparers
                        .max(active_adaptive_preparers);
                    (key, checksum)
                })
            } else {
                None
            };

            if let Some(request) = adaptive_demand_request {
                self.changed.notify_all();
                drop(state);
                self.prepare_claimed(request, true)?;
                state = self.state.lock();
                continue;
            }

            if let Some(instance) = available {
                if waited {
                    let wait_elapsed = wait_started.elapsed();
                    state.metrics.waited_requests += 1;
                    state.metrics.aggregate_wait_time += wait_elapsed;
                    if let Some(diagnostics) = diagnostics {
                        diagnostics.record_wasm_pool_wait(wait_elapsed);
                    }
                } else {
                    state.metrics.immediate_hits += 1;
                }
                state.metrics.consumed_instances += 1;
                self.changed.notify_all();
                break instance;
            }
            self.changed.notify_all();
            self.changed.wait(&mut state);
        };
        drop(state);

        let rebind_started = Instant::now();
        instance
            .with_storage(|storage| {
                storage.rebind(contract.clone(), depth, tx.clone());
                Ok(())
            })
            .map_err(EngineError::from)?;
        instance
            .with_querier(|querier| {
                querier.rebind(
                    self.core.clone(),
                    tx,
                    contract,
                    block,
                    depth,
                );
                Ok(())
            })
            .map_err(EngineError::from)?;
        let rebind_elapsed = rebind_started.elapsed();
        self.state.lock().metrics.aggregate_rebind_time += rebind_elapsed;
        if let Some(diagnostics) = diagnostics {
            diagnostics.record_wasm_pool_rebind(rebind_elapsed);
        }
        Ok(instance)
    }

    pub(crate) fn worker_done(&self) {
        let mut state = self.state.lock();
        state.active_execution_workers = state.active_execution_workers.saturating_sub(1);
        self.changed.notify_all();
    }

    pub(crate) fn metrics(&self) -> WasmInstancePoolMetrics {
        let state = self.state.lock();
        let mut metrics = state.metrics;
        metrics.unused_instances = state
            .entries
            .values()
            .map(|entry| entry.available.len() as u64)
            .sum();
        metrics
    }

    fn next_adaptive_prepare_request(
        &self,
        state: &mut PoolState,
    ) -> Option<(CodeChecksum, Checksum)> {
        let low_watermark = self.config.low_watermark();

        // Uncovered waiters always activate refill, irrespective of the reserve watermark.
        let has_uncovered_waiters = state.entries.values().any(|entry| {
            entry.available.len() + entry.creating < entry.waiters
        });
        if has_uncovered_waiters
            || (!state.adaptive_refill_active
                && state.entries.values().any(|entry| {
                    entry.available.len() + entry.creating < low_watermark
                }))
        {
            state.adaptive_refill_active = true;
        }

        if !state.adaptive_refill_active {
            return None;
        }

        let request = {
            let PoolState { entries, metrics, .. } = state;
            let mut request = None;
            for (key, entry) in entries.iter_mut() {
                if entry.available.len() + entry.creating < entry.waiters {
                    entry.creating += 1;
                    metrics.demand_prepare_requests += 1;
                    request = Some((*key, entry.checksum));
                    break;
                }
            }
            if request.is_none() {
                for (key, entry) in entries.iter_mut() {
                    if entry.available.len() + entry.creating < self.config.target_per_code {
                        entry.creating += 1;
                        metrics.background_prepare_requests += 1;
                        request = Some((*key, entry.checksum));
                        break;
                    }
                }
            }
            request
        };

        if request.is_none() {
            state.adaptive_refill_active = false;
        }
        request
    }

    fn next_prepare_request(
        &self,
        state: &mut PoolState,
    ) -> Option<(CodeChecksum, Checksum)> {
        // First satisfy active demand. This prevents an alphabetically earlier predicted code from
        // filling its background target while a nested/dynamic code already has execution workers
        // blocked waiting for a pristine instance.
        let PoolState { entries, metrics, .. } = state;
        for (key, entry) in entries.iter_mut() {
            if entry.available.len() + entry.creating < entry.waiters {
                entry.creating += 1;
                metrics.demand_prepare_requests += 1;
                return Some((*key, entry.checksum));
            }
        }

        // With all current waiters covered, restore the steady-state reserve for each code.
        for (key, entry) in entries.iter_mut() {
            if entry.available.len() + entry.creating < self.config.target_per_code {
                entry.creating += 1;
                metrics.background_prepare_requests += 1;
                return Some((*key, entry.checksum));
            }
        }
        None
    }
}

thread_local! {
    static ACTIVE_POOL: RefCell<Option<Arc<FreshWasmInstancePool>>> = RefCell::new(None);
}

pub(crate) struct FreshWasmPoolWorkerGuard {
    pool: Arc<FreshWasmInstancePool>,
}

impl FreshWasmPoolWorkerGuard {
    pub(crate) fn install(pool: Arc<FreshWasmInstancePool>) -> Self {
        ACTIVE_POOL.with(|slot| {
            debug_assert!(slot.borrow().is_none());
            *slot.borrow_mut() = Some(pool.clone());
        });
        Self { pool }
    }
}

impl Drop for FreshWasmPoolWorkerGuard {
    fn drop(&mut self) {
        ACTIVE_POOL.with(|slot| {
            *slot.borrow_mut() = None;
        });
        self.pool.worker_done();
    }
}

pub(crate) fn active_pool() -> Option<Arc<FreshWasmInstancePool>> {
    ACTIVE_POOL.with(|slot| slot.borrow().clone())
}

fn code_checksum(checksum: &Checksum) -> CodeChecksum {
    let mut bytes = [0_u8; 32];
    bytes.copy_from_slice(checksum.as_slice());
    CodeChecksum::new(bytes)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn engine_wasm_instance_is_send_for_cross_thread_preparation() {
        fn assert_send<T: Send>() {}
        assert_send::<EngineWasmInstance>();
    }

    #[test]
    fn pool_configuration_is_disabled_unless_threads_and_capacity_are_positive() {
        assert!(!WasmInstancePoolConfig::default().enabled());
        assert!(!WasmInstancePoolConfig {
            preparer_threads: 1,
            target_per_code: 0,
            initial_per_code: 0,
            ..WasmInstancePoolConfig::default()
        }
        .enabled());
        assert!(WasmInstancePoolConfig {
            preparer_threads: 1,
            target_per_code: 2,
            initial_per_code: 1,
            ..WasmInstancePoolConfig::default()
        }
        .enabled());
    }

    #[test]
    fn fresh_preparation_rejects_wasm_start_sections_conservatively() {
        let header = b"\0asm\x01\0\0\0";
        assert!(wasm_allows_fresh_instance_preparation(header));

        let mut with_start = header.to_vec();
        with_start.extend_from_slice(&[8, 1, 0]);
        assert!(!wasm_allows_fresh_instance_preparation(&with_start));

        let mut truncated = header.to_vec();
        truncated.extend_from_slice(&[1, 0x80]);
        assert!(!wasm_allows_fresh_instance_preparation(&truncated));
    }
}
